﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Project1Bank;

namespace Bank1ProjectUnitTests.nUnitTests
{
    internal class FrontendAdminTests
    {
        [SetUp]
        public void Setup()
        {
            AdminGUI adminFrontendClass = new AdminGUI();

        }

        [TearDown]
        public void After()
        {

        }
        //TODO test user input and outputs
        //TODO 
        [Test]
        public void Test1()
        {
            Assert.Pass();

        }
    }
}
