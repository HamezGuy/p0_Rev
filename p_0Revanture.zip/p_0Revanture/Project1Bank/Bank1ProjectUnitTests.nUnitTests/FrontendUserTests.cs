﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Project1Bank;

namespace Bank1ProjectUnitTests.nUnitTests
{
    internal class FrontendUserTests
    {
        private StringWriter stringWriter;
        private StringReader stringReader;

        [SetUp]
        public void Setup()
        {
            UserGUI userFrontendClass = new UserGUI();
            stringWriter = new StringWriter();
            stringReader = new StringReader("");

            Console.SetOut(stringWriter);
            Console.SetIn(stringReader);
        }

        [TearDown]
        public void After()
        {
            
        }

        //TODO test user input and outputs
        //TODO 
        [Test]
        public void Test1()
        {
            

        }
    }
}
