﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Project1Bank;

namespace Bank1ProjectUnitTests.nUnitTests
{
    internal class ToAndFromJSONTests
    {
        [SetUp]
        public void Setup()
        {
            ToAndFromJSON jsonClass = new ToAndFromJSON();

        }

        [TearDown]
        public void After()
        {

        }
        //TODO test user input and outputs
        //TODO 
        [Test]
        public void Test1()
        {
            Assert.Pass();

        }

        [Test]
        public void Test2()
        {
            
        }
    }
}
