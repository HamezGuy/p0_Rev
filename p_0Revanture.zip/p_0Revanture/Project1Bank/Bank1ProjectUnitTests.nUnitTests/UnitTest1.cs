namespace Bank1ProjectUnitTests.nUnitTests
{
    using Project1Bank;

    public class Tests
    {
        [SetUp]
        public void Setup()
        {
            

        }

        [TearDown]
        public void After()
        {

        }
        //TODO test user input and outputs
        //TODO 
        [Test]
        public void Test1()
        {
            Assert.Pass();
            
        }

        [Test]
        public void Test2()
        {
            Assert.Pass();
        }
    }
}