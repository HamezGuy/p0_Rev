﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Serilog;


namespace Project1Bank
{
    internal class AdminBackend : IAdminBackendInterface
    {
        //global fields
        //private Dictionary<int, JSONStructure> allAccounts = new Dictionary<int, JSONStructure>();
        //private Dictionary<int, AdminJSONStructure> allAdminAccountsDictionary = new Dictionary<int, AdminJSONStructure>();
        private ToAndFromJSON jsonConverter = new ToAndFromJSON();
        //private List<JSONStructure> allAccountsList = new List<JSONStructure>();
        //private List<AdminJSONStructure> allAdminAccounts = new List<AdminJSONStructure>();
        private AdminJSONStructure? currentAdminAccount;

        private static float amountToWithdrawSavings = 20000;
        private static float amountToWithdrawChecking = 50000;
        private static float amountToWithdrawInvestingPercentage = .7f;

        //note, use datetimevar.ToString(region) to convert to string 

        private static int minUsernameLength = 8;
        private static int minNameLength = 2;


        /**
         * this constructor is responsible for initializing the accounts list and accounts dictionary
         * 
         * @params 
         * none
         */
        public AdminBackend()
        {
            try
            {
                Log.Logger = new LoggerConfiguration().WriteTo.File(@"D://RevStuff//RevProjects//Project1//Project1Bank//SerilogData.txt").CreateLogger();
            }
            catch(Exception)
            {

            }
            
        }

        public int ReturnAdminNumberOfAttempts(string userName)
        {
            try
            {
                AdminJSONStructure? account = jsonConverter.GetFromJSONAdmin(userName);

                if(account == null)
                {
                    throw new Exception();
                }

                return account.numberOfLoginAttempts;
            }
            catch(Exception e)
            {
                Log.Error(e.ToString());
                return -1;
            }
        }

        //MUST CALL THIS BEFORE LOGIN TO ACCOUNT, don't worry about big o, there shouldn't be that many admins, a few dozen thousand at most
        public bool CheckIfAccountExists(int accountNumber)
        {
            if (jsonConverter.CheckIfAccountExists(accountNumber))
                return true;

            return false;
        }

        public bool CheckIfAccountExists(string userName)
        {

            if (jsonConverter.CheckIfAccountExists(userName))
            {
                return true;
            }

            return false;
        }

        public bool CheckIfAccountExistsAdmin(int accountNumber)
        {
            if (jsonConverter.CheckIfAccountExistsAdmin(accountNumber))
                return true;

            return false;
        }

        public bool CheckIfAccountExistsAdmin(string userName)
        {
            if (jsonConverter.CheckIfAccountExistsAdmin(userName))
                return true;

            return false;
        }

        /*
        private void RefreshAdminAccounts()
        {
            try
            {
                allAdminAccounts.Clear();

                allAdminAccounts = jsonConverter.GetFromJSONAdmin();


                if (allAccountsList == null)
                {
                    throw new NullReferenceException("No file found or other issue involving parsing");
                }

                foreach (AdminJSONStructure account in allAdminAccounts)
                {
                    if (account == null)
                    {
                        throw new NullReferenceException("corrupted file");
                    }

                    if (account?.accountNumber == null)
                    {
                        throw new NullReferenceException("corruped file");
                    }

                    allAdminAccountsDictionary?.Add(account.accountNumber, account);

                }

            }
            catch (NullReferenceException e)
            {
                Console.WriteLine(e.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine("Unknown error occured");
                _logger.Error(e.ToString());
            }
        }
    */

        //TODO refactor since new json object
        public int LoginToAccountAdmin(string userName, string passWord)
        {
            //README, assumes that check if account exists was already called, nothing will really happen if its not but makes it easier

            try
            {
                
                currentAdminAccount = jsonConverter.GetFromJSONAdmin(userName);

                if(currentAdminAccount == null)
                {
                    throw new NullReferenceException();
                }

                if(currentAdminAccount.numberOfLoginAttempts >= 3)
                {
                    return -1;
                }
 

                if(!currentAdminAccount.userPassword.Equals(passWord))
                {
                    currentAdminAccount.numberOfLoginAttempts++;
                    jsonConverter.UpdateSQL(currentAdminAccount);
                    throw new ArgumentException();
                }


                currentAdminAccount.numberOfLoginAttempts = 0;
                jsonConverter.UpdateSQL(currentAdminAccount);
                return 0;
            }
            catch(ArgumentException)
            {
                //for password not matching only
                currentAdminAccount = null;
                return 1;
            }
            catch(NullReferenceException)
            {
                currentAdminAccount = null;
                return 2;
            }
            catch(Exception e)
            {
                currentAdminAccount = null;
                Log.Error(e.ToString());
                return 3;
            }
  
        }

        

        public bool CreateNewAdminAccount(string firstName, string lastName, string userName, string userPassword)
        {
            int? accountNumber = 0;
            DateTime currentTime = DateTime.Now;

            try
            {
                accountNumber = jsonConverter.ReturnMaxAccountNumberAdmin() + 1;
                if(!accountNumber.HasValue)
                {
                    throw new Exception();
                }

                if(jsonConverter.CheckIfAccountExistsAdmin(userName))
                {
                    return false;
                }

                int numberOfLoginAttempts = 0;

                AdminJSONStructure adminAccount = new AdminJSONStructure(firstName, lastName, userName, userPassword, numberOfLoginAttempts,
                    accountNumber.Value, currentTime);

                
                if(!jsonConverter.WriteToJSON(adminAccount))
                {
                    throw new Exception();
                }

            }
            catch(Exception e)
            {
                Log.Error(e.ToString());
                return false;
            }

            return true;
        }

        /**
         * this method is responsible for ...
         * 
         * @params 
         * none
         * 
         * @return 
         * void
         */
        public bool CreateNewAccount(string firstName, string lastName, string userName,
            string passWord, float checkingBalance, float savingAccountBalance, float investmentAccountBalance,
            accountStatusEnum accountStatus, string additionalNotes = "")
        {

            JSONStructure newAccount;
            int? accountNumber = jsonConverter.ReturnMaxAccountNumber() + 1;

            if(!accountNumber.HasValue)
            {
                return false;
            }

            DateTime currentTime = DateTime.Now;

            try
            {
                
                if(jsonConverter.CheckIfAccountExists(userName))
                {
                    throw new ArgumentException("Username already taken, please enter a new one");
                }

                if(savingAccountBalance < 0 || investmentAccountBalance < 0 || checkingBalance < 0)
                {
                    throw new ArgumentException("Please enter a valid account value");
                }

                List<string> transactions = new List<string>();

                int numberOfAttempts = 0;

                bool isUnlocked = true;

                newAccount = new JSONStructure(firstName, lastName, userName, passWord, savingAccountBalance, checkingBalance,
                    investmentAccountBalance, accountNumber.Value, isUnlocked, numberOfAttempts, currentTime, transactions);

                //TODO create account number based on existing accounts
                //TODO create account based on highest number account currently available
     
                if(!jsonConverter.WriteToJSON(newAccount))
                {
                    throw new ArgumentException();
                }
                

            }
            catch(ArgumentException e)
            {
                Log.Error(e.ToString());
                return false;
            }
            catch(Exception e)
            {
                Log.Error(e.ToString());
                return false;
            }

            return true;
        }



        /**
         * this method is responsible for ...
         * 
         * @params 
         * none
         * 
         * @return 
         * void
         */
        public List<JSONStructure>? ViewAllAccountDetails()
        {
            List<JSONStructure>? accountDetails = jsonConverter.returnAllAccountDetails();
            if(accountDetails == null)
            {
                return null;
            }

            return jsonConverter.returnAllAccountDetails();
        }

        //TODO CHANGE TO HASHMAP INSTEAD OF list
        public void WithdrawFromAccount(int accountNumber, float amountToWithdraw, accountTypeEnum typeOfAccount)
        {
            string message;

            try
            {
                if (amountToWithdraw <= 0)
                {
                    throw new ArgumentException("amount entered should not be negitive");
                }

                JSONStructure account = jsonConverter.GetFromJSON(accountNumber); //TODO make sure its pass by reference

                if(account == null)
                {
                    throw new NullReferenceException("account is null");
                }

                switch (typeOfAccount)
                {
                    case accountTypeEnum.investment:
                        account.investmentAccountBalance -= amountToWithdraw;
                        break;
                    case accountTypeEnum.checking:
                        account.checkingAccountBalance -= amountToWithdraw;
                        break;
                    case accountTypeEnum.saving:
                        account.savingAccountBalance -= amountToWithdraw;
                        break;
                    default:
                        throw new ArgumentException("Error with method");

                }

                message = "Transaction: withdraw " + amountToWithdraw + " from account " + typeOfAccount.ToString();
                DateTime currentTime = DateTime.Now;
                if (LogTransaction("Admin", message, accountNumber, currentTime) == null)
                {
                    throw new Exception();
                }

                jsonConverter.UpdateSQL(account);
            }
            catch(ArgumentException e)
            {
                Log.Error(e.ToString());
            }
            catch(NullReferenceException e)
            {
                Log.Error(e.ToString());
            }
            catch(Exception e)
            {
                Log.Error(e.ToString());
            }

            return;
        }

        public bool? LogTransaction(string p_adminOrUser, string p_messageToLog, int p_accountNumber, DateTime timeOfTransaction)
        {
            string messageToLogFinalized = p_messageToLog + " transaction made by: " + p_adminOrUser;
            try
            {
                bool? boolValueOfMethod = jsonConverter.UpdateTransactionTable(p_accountNumber, messageToLogFinalized, timeOfTransaction);
                if (boolValueOfMethod == null)
                {
                    throw new Exception();
                }
                else if(boolValueOfMethod.Value == false)
                {
                    return false;
                }
                else
                {
                    return true;
                }

            }
            catch (Exception e)
            {
                Log.Error(e.ToString());
                return null;
            }
        }

        /*
         * 
         * 
         * 
         * README: while I could put withdraw and deposite in same method, since "money" (program won't be used) is involved its always better to be clearer
         */
        public void DepositeToAccount(int accountNumber, float amountToDeposit, accountTypeEnum typeOfAccount)
        {
            string message;

            try
            {
                if(amountToDeposit < 0)
                {
                    //README: already checked in user handeling, but will always have additonal checks in backend in case of hacks to frontend
                    throw new ArgumentException("amount to withdraw should be a positive number");
                }
                JSONStructure account = jsonConverter.GetFromJSON(accountNumber);

                if(account == null)
                {
                    throw new NullReferenceException();
                }

                switch(typeOfAccount)
                {
                    case accountTypeEnum.investment:
                        account.investmentAccountBalance += amountToDeposit;
                        break;
                    case accountTypeEnum.checking:
                        account.checkingAccountBalance += amountToDeposit;
                        break;
                    case accountTypeEnum.saving:
                        account.savingAccountBalance += amountToDeposit;
                        break;
                    default: 
                        throw new ArgumentException("Error with method");

                }

                message = "Transaction: deposit " + amountToDeposit + " to account " + typeOfAccount.ToString();
                DateTime currentTime = DateTime.Now;
                if (LogTransaction("Admin", message, accountNumber, currentTime) == null)
                {
                    throw new Exception();
                }

                jsonConverter.UpdateSQL(account); //TODO check that is works as expected, value in dictionary should be stored as a reference

                Console.WriteLine("Executed");
            }
            catch (ArgumentException e)
            {
                Log.Error(e.ToString());
            }
            catch (NullReferenceException e)
            {
                Log.Error(e.ToString());
            }
            catch (Exception e)
            {
                Log.Error(e.ToString());
            }
            return;
        }


        /**
         * this method is responsible for ...
         * 
         * @params 
         * none
         * 
         * @return 
         * void
         */
        public bool TransferFunds(int accountToTransferFrom, int accountToTransferTo, float amountToTransfer, accountTypeEnum typeOfAccountTransferFrom,
            accountTypeEnum typeOfAccountTransferTo)
        {
            string message; 

            try
            {

                if (amountToTransfer < 0)
                {
                    //README: already checked in user handeling, but will always have additonal checks in backend in case of hacks to frontend
                    throw new ArgumentException("amount to withdraw should be a positive number");
                }

                JSONStructure? accountToTransferFromAccount = jsonConverter.GetFromJSON(accountToTransferFrom);
                JSONStructure? accountToTransferToAccount = jsonConverter.GetFromJSON(accountToTransferTo);


                if (accountToTransferFromAccount == null || accountToTransferToAccount == null)
                {
                    throw new NullReferenceException("should not be null");
                }

                switch (typeOfAccountTransferFrom)
                {
                    case accountTypeEnum.investment:
                        accountToTransferFromAccount.investmentAccountBalance -= amountToTransfer;
                        break;
                    case accountTypeEnum.checking:
                        accountToTransferFromAccount.checkingAccountBalance -= amountToTransfer;
                        break;
                    case accountTypeEnum.saving:
                        accountToTransferFromAccount.savingAccountBalance -= amountToTransfer;
                        break;
                    default:
                        throw new ArgumentException("Error with method");
                }

                switch(typeOfAccountTransferTo)
                {
                    case accountTypeEnum.investment:
                        accountToTransferToAccount.investmentAccountBalance += amountToTransfer;
                        break;
                    case accountTypeEnum.checking:
                        accountToTransferToAccount.checkingAccountBalance += amountToTransfer;
                        break;
                    case accountTypeEnum.saving:
                        accountToTransferToAccount.savingAccountBalance += amountToTransfer;
                        break;
                    default:
                        throw new ArgumentException("Error with method");
                }

                jsonConverter.UpdateSQL(accountToTransferFromAccount);
                jsonConverter.UpdateSQL(accountToTransferToAccount);

                message = "Transaction: transfer " + amountToTransfer + " from account " + accountToTransferFrom.ToString()
                    + " to account " + accountToTransferTo.ToString();

                DateTime currentTime = DateTime.Now;
                if (LogTransaction("Admin", message, accountToTransferFrom, currentTime) == null)
                {
                    throw new Exception();
                }


            }
            catch (ArgumentException e)
            {
                Log.Error(e.ToString());
                return false;
            }
            catch (NullReferenceException e)
            {
                Log.Error(e.ToString());
                return false;
            }
            catch (Exception e)
            {
                Log.Error(e.ToString());
                return false;
            }
            return true;
        }

        /**
         * this method is responsible for ...
         * 
         * @params 
         * none
         * 
         * @return 
         * void
         */
        public void EnableOrDisableAccount(int accountNumber, bool enableAccount)
        {
            try
            {
                if(!jsonConverter.CheckIfAccountExists(accountNumber))
                {
                    throw new ArgumentException();
                }

                JSONStructure? account = jsonConverter.GetFromJSON(accountNumber); 

                if (account == null)
                {
                    throw new NullReferenceException();
                }

                account.isAccountUnlocked = enableAccount;
                if(enableAccount == true)
                {
                    account.numberOfAttempts = 0;
                }

                jsonConverter.UpdateSQL(account);
                Console.WriteLine("Executed");

            }
            catch(ArgumentException)
            {
                Console.WriteLine("no such account found");
            }
            catch(NullReferenceException e)
            {
                Log.Error(e.ToString());
            }
            catch(Exception e)
            {
                Log.Error(e.ToString());
            }
            return;
        }

        //TODO enable or disable admin account?
        public bool EnableAdminLogin()
        {
            return true;
        }

        private int? FindLargestKeyUser()
        {

            return jsonConverter.ReturnMaxAccountNumber();
        }

        private int? FindLargestKeyAdmin()
        {

            return jsonConverter.ReturnMaxAccountNumberAdmin();
        }

        public bool MaxLimitTransactions(accountTypeEnum typeOfAccount, float amountToWithdraw, int accountNumber)
        {
            JSONStructure? account = jsonConverter.GetFromJSON(accountNumber);
            if(account == null)
            {
                return false;
            }

            switch (typeOfAccount)
            {
                case accountTypeEnum.saving:
                    if(amountToWithdraw > amountToWithdrawSavings)
                    {
                        return false;
                    }
                    return true;
                case accountTypeEnum.checking:
                    if(amountToWithdraw > amountToWithdrawChecking)
                    {
                        return false;
                    }
                    return true;
                case accountTypeEnum.investment:
                    if(amountToWithdraw > amountToWithdrawInvestingPercentage * account.investmentAccountBalance)
                    {
                        return false;
                    }
                    return true;
                default:
                    return false;
            }
        }

    }
}
