﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Serilog;

namespace Project1Bank
{
    /*
     * 
     * 
     * 
     * README: no implimented interface, unneeded for large group projects esp as a GUI
     */
    public class AdminGUI
    {
        //global fields
        AdminBackend backendClass;

        private static int maxPasswordLength = 30; //TODO actual checks should occur on backend, this is just for reference checking frontend
        private static int minPasswordLength = 8;


        public AdminGUI()
        {
            backendClass = new AdminBackend();
        }

        public virtual void AdminLogin() 
        {

            string? userInput;
            string userName;
            string passWord;
            int loginInt;
            int loginAttempts;

            PrintTitle();
            while(true)
            {
                try
                {
                    Console.WriteLine("Admin Login: Please enter your username to log or enter q to exit");

                    userInput = Console.ReadLine();

                    if(userInput == null)
                    {
                        throw new NullReferenceException("Please enter a valid value");
                    }

                    if(userInput == "q" || userInput == "Q")
                    {
                        Console.WriteLine("returning to main menu");
                        return;
                    }

                    if(!backendClass.CheckIfAccountExistsAdmin(userInput))
                    {
                        throw new ArgumentException("Could not find the username, please enter a valid username");
                    }
                    else
                    {
                        userName = userInput;
                    }

                    break;
                }
                catch(ArgumentException e)
                {
                    Console.WriteLine(e.Message);
                }
                catch(NullReferenceException e)
                {
                    Console.WriteLine(e.Message);
                }
                catch(Exception e)
                {
                    Console.WriteLine(e.StackTrace);
                }
            }


            while(true)
            {
                try
                {
                    loginAttempts = backendClass.ReturnAdminNumberOfAttempts(userName); 

                    if(loginAttempts >= 3)
                    {
                        Console.WriteLine("more than 3 login attempts on record for this account" +
                            ", account is locked, please enter q to return to main menu");  
                    }
                    else
                    {
                        Console.WriteLine("Welcome " + userName + ", please enter your password to log in or enter q to exit to main menu");
                        Console.WriteLine("Note: for this project I was told to remove the number of times for admin tries: ");
                    }

                    userInput = Console.ReadLine();
                    if (userInput == null)
                    {
                        throw new NullReferenceException("Please enter a valid password");
                    }

                    if(userInput == "q" || userInput == "Q")
                    {
                        Console.WriteLine("Exiting to main menu");
                        return;
                    }
                    else if(loginAttempts >= 3)
                    {
                        throw new ArgumentException("");
                    }
                    else
                    {
                        passWord = userInput;
                    }

                    loginInt = backendClass.LoginToAccountAdmin(userName, passWord);

                    switch(loginInt)
                    {
                        case -1:
                            throw new ArgumentException("Over 3 password attempts entered, no more login attempts allowed");
                        case 0:
                            Console.WriteLine("Login Successful, entering account");
                            break;
                        case 1:
                            loginAttempts++;
                            throw new ArgumentException("Password does not match, please try again");
                        case 2:
                            throw new NullReferenceException("issue accessing account");
                        case 3:
                            throw new Exception();
                        default:
                            throw new Exception();
                    }

                    break;
                }
                catch (ArgumentException e)
                {
                    Console.WriteLine(e.Message);
                }
                catch (NullReferenceException e)
                {
                    Console.WriteLine(e.Message);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.StackTrace);
                }
            }
            

            //TODO need to figure out how exactly I want to loop this 
            while(true)
            {
                ShowOptions();
            }
            
        }

        private void ShowOptions()
        {
            int userIntInput;

            while (true)
            {
                PrintTitle();
                Console.WriteLine("");
                Console.WriteLine("Welcome Admin to TestBank");

                Console.WriteLine("Please choose from the options below (Example: enter 1 for selection 1)");
                Console.WriteLine("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                Console.WriteLine("1. Open a new Account (Admin and User)");
                Console.WriteLine("2. View all Account details");
                Console.WriteLine("3. Withdraw from a Account");
                Console.WriteLine("4. Deposit to a Account");
                Console.WriteLine("5. Transfer funds between Accounts");
                Console.WriteLine("6. Disable an Account");
                Console.WriteLine("7. Activate a blocked Account");
                Console.WriteLine("8. Exit");

                try
                {
                    string? tempUserInput = Console.ReadLine();

                    if (tempUserInput == null)
                    {
                        throw new NullReferenceException("Please enter a valid value");
                    }

                    if (int.TryParse(tempUserInput, out userIntInput))
                    {
                        if (userIntInput >= 1 && userIntInput <= 8) //magic numbers, but is the number of options above, seems self expanitory so didn't make vars
                        {
                            break;
                        }
                        else
                        {
                            throw new ArgumentException("Please enter a currect numerical value between 1-8");
                        }
                    }
                    else
                    {
                        throw new ArgumentException("Please enter a currect numerical value between 1-8");
                    }


                }
                catch (ArgumentException e)
                {
                    Console.WriteLine(e.Message);
                }
                catch (NullReferenceException e)
                {
                    Console.WriteLine(e.Message);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.StackTrace);
                }
            }

            switch(userIntInput)
            {
                case 1:
                    CreateAdminOrUserAccount();
                    break;

                case 2:
                    ViewAllAccounts();
                    break;

                case 3:
                    withdrawOrDepositEnum tempWithdraw = withdrawOrDepositEnum.withdraw;
                    WithdrawAndDepositFunds(tempWithdraw);
                    break;

                case 4:
                    withdrawOrDepositEnum tempDeposite = withdrawOrDepositEnum.deposit;
                    WithdrawAndDepositFunds(tempDeposite);
                    break;

                case 5:
                    TransferToAnotherAccount();
                    break;

                case 6:
                    bool tempActivate = false;
                    ActiviateOrDeactivateAccount(tempActivate);
                    break;

                case 7:
                    bool tempDeactivate = true;
                    ActiviateOrDeactivateAccount(tempDeactivate);
                    break;

                case 8:
                    Exit();
                    break;

                default:
                    Console.WriteLine("error coming here, returning");
                    return;
            }
               
            return;
        }

        private void CreateAdminOrUserAccount()
        {
            int userIntInput;
            string? userInput;
            while (true)
            {
                try
                {
                    PrintTitle();

                    Console.WriteLine("Please choose the type of account you wish to create (1 or 2) or enter q to return to main menu" +
                        "\n1. Admin Account\n2. User Account");

                    userInput = Console.ReadLine().Trim().ToLower();
                    if(userInput == null)
                    {
                        Console.WriteLine("Terminating process, exiting to main");
                        return;
                    }

                    if(!int.TryParse(userInput, out userIntInput))
                    {
                        throw new ArgumentException("Please enter a valid value (1 or 2)");
                    }

                    if( !( userIntInput != 1 || userIntInput != 2 ))
                    {
                        throw new ArgumentException("Please enter a valid value (1 or 2)");
                    }

                    if(userIntInput.Equals(1))
                    {
                        CreateAdminAccount();
                        return;
                    }
                    else if(userIntInput.Equals(2))
                    {
                        CreateAccount();
                        return;
                    }
                    
                }
                catch(ArgumentException e)
                {
                    Console.WriteLine(e.Message);
                }
                catch(Exception e)
                {
                    Console.WriteLine(e.StackTrace);
                }
            }
        }

        private void PrintTitle()
        {
            Console.Clear();
            Console.WriteLine(@"
████████ ███████ ███████ ████████ ██████   █████  ███    ██ ██   ██ 
   ██    ██      ██         ██    ██   ██ ██   ██ ████   ██ ██  ██  
   ██    █████   ███████    ██    ██████  ███████ ██ ██  ██ █████   
   ██    ██           ██    ██    ██   ██ ██   ██ ██  ██ ██ ██  ██  
   ██    ███████ ███████    ██    ██████  ██   ██ ██   ████ ██   ██ 
                                                                    
                                                                    
        ");
        }



            /// <summary>
            /// 
            /// </summary>
            /// //TODO
            private void CreateAdminAccount()
        {
            string? firstName = null;
            string? lastName = null;
            string? userName = null;
            string? userPassword = null;
            

            while(true)
            {
                try
                {
                    PrintTitle();

                    Console.WriteLine("Creating a new administrator account, Please enter any value to continue or press q now to exit");
                    string? tempString = Console.ReadLine().Trim().ToLower();

                    if (tempString.Equals("q"))
                    {
                        Console.WriteLine("Terminating process and exiting to main menu");
                        return;
                    }

                    firstName = CreateAccountHelperGUI("first name");
                    if (firstName == null)
                    {
                        Console.WriteLine("Terminating process and exiting to main menu");
                        return;
                    }

                    lastName = CreateAccountHelperGUI("last name");
                    if(lastName == null)
                    {
                        Console.WriteLine("Terminating process and exiting to main menu");
                        return;
                    }

                    userName = CreateAccountHelperUserNameGUI(1);
                    if(userName == null)
                    {
                        Console.WriteLine("Terminating process and exiting to main menu");
                        return;
                    }

                    userPassword = CreateAccountHelperPassword(firstName, lastName);
                    if (userPassword == null)
                    {
                        Console.WriteLine("Terminating process and exiting to main menu");
                        return;
                    }

                    if ( !backendClass.CreateNewAdminAccount(firstName, lastName, userName, userPassword) )
                    {
                        Console.WriteLine("Error creating a new admin account");
                        
                    }

                    Console.WriteLine("Successfully created a new admin account");

                    break;

                }
                catch (ArgumentException e)
                {
                    Console.WriteLine(e.Message);
                }
                catch (Exception)
                {
                    Console.WriteLine("Error occured while creating the account, exiting to main menu");
                    return;
                }
            }

            while (true)
            {
                Console.WriteLine("Please enter q to return to main menu");

                string? userInput = Console.ReadLine().ToLower().Trim();
                if (userInput == null)
                {
                    Console.WriteLine("please enter a valid value");
                }
                else if (userInput == "q")
                {
                    return;
                }
            }

        }


        /*
         * This method creates and stores a user account 
         * No params
         * return of bool if successful, false if unsuccessful, exits if user decides to exit
         */
        private bool CreateAccount()
        {
            string? firstName = null;
            string? lastName = null;
            string? userName = null;
            string? userPassword = null;
            float? accountBalanceChecking  = null;
            float? accountBalanceSavings = null;
            float? accountBalanceInvesting = null;
            accountStatusEnum accountStatus = accountStatusEnum.enabled;

            while (true)
            {
                try
                {
                    PrintTitle();
                    //writes to user 
                    Console.WriteLine("Creating new account, Please enter any value to continue or press q now to exit");
                    string? tempString = Console.ReadLine().Trim().ToLower();
                    if(tempString.Equals("q"))
                    {
                        return false;
                    }

                    firstName = CreateAccountHelperGUI("firstName");
                    if (firstName == null)
                    {
                        return false;
                    }

                    lastName = CreateAccountHelperGUI("lastName");
                    if (lastName == null)
                    {
                        return false;
                    }

                    userName = CreateAccountHelperUserNameGUI(0);
                    if (userName == null)
                    {
                        return false;
                    }

                    userPassword = CreateAccountHelperPassword(firstName, lastName);
                    if (userPassword == null)
                    {
                        return false;
                    }

                    accountBalanceChecking = CreateAccountBalanceHelper("Please enter the starting account balance for the checking account");
                    if (!accountBalanceChecking.HasValue)
                    {
                        return false;
                    }

                    accountBalanceSavings = CreateAccountBalanceHelper("Please enter the starting account balance for the savings account");
                    if (!accountBalanceSavings.HasValue)
                    {
                        return false;
                    }

                    accountBalanceInvesting = CreateAccountBalanceHelper("Please enter the starting account balance for the investing account");
                    if (!accountBalanceInvesting.HasValue)
                    {
                        return false;
                    }

                    accountStatus = accountStatusEnum.enabled;

                    //make sure they're in the order of the function
                    if (backendClass.CreateNewAccount(firstName, lastName, userName, userPassword, accountBalanceChecking.Value, 
                        accountBalanceSavings.Value, accountBalanceInvesting.Value, accountStatus))
                    {
                        Console.WriteLine("Account Successfully Created. Going back to main menu");
                    }
                    else
                    {
                        throw new ArgumentException("Account creation failed, please enter the new values or exit");
                    }

                    break;

                }
                catch (ArgumentException e)
                {
                    Console.WriteLine(e.Message);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                    return false;
                }
            }

            while (true)
            {
                Console.WriteLine("Please enter q to return to main menu");

                string? userInput = Console.ReadLine().ToLower().Trim();
                if (userInput == null)
                {
                    Console.WriteLine("please enter a valid value");
                }
                else if (userInput == "q")
                {
                    return true;
                }

            }

            return true;
        }


        /*
         * This method is a helper method for ChangeUserAccountData
         * This method prompts user to withdraw or deposit amounts into their savings, takes in user value and modifies accordingly
         * @params 
         * JSONStructure account, account to modify
         * string withOrDep string value stating weather to deposit or withdraw
         * 
         * 3, 4
         */
        private bool? WithdrawAndDepositFunds(withdrawOrDepositEnum withdrawOrDep)
        {


            int accountNumber = 0;
            float? amountToWithdraw = null;
            accountTypeEnum? typeOfAccount = null;
            
            while(true)
            {
                try
                {
                    PrintTitle();

                    string tempMessage = "Please type in the account number you wish to " + withdrawOrDep.ToString() + " to";

                    int? tempAccountNumber = UserAccountInput(tempMessage);

                    if (tempAccountNumber.HasValue)
                    {
                        accountNumber = tempAccountNumber.Value;
                    }
                    else
                    {
                        Console.WriteLine("Terminating process exiting to main menu");
                        return null;
                    }

                    if(backendClass.CheckIfAccountExists(accountNumber) == false)
                    {
                        throw new ArgumentException("Please enter a new account value, could not find the original");
                    }

                    tempMessage = "Is this the correct account you want to access? " + accountNumber + " [y]es or [n]o";

                    bool? checkValueInt = ClarifyUserInput(tempMessage); 

                    switch (checkValueInt)
                    {
                        case true:
                            break; //only other break from while loop
                        case false:
                            throw new ArgumentException("Please enter a new account value");
                        case null:
                            Console.WriteLine("Terminating process exiting to main menu");
                            return null;
                    }

                    break;
                }
                catch (ArgumentException e)
                {
                    Console.WriteLine(e.Message);
                }
                catch (NullReferenceException e)
                {
                    Console.WriteLine(e.Message);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.StackTrace);
                }
            }

            try
            {
                typeOfAccount = TypeOfAccountUserInput("Please enter the type of account " +
                    "you wish to " + withdrawOrDep.ToString() + " from");
            }
            catch (Exception e)
            {
                Console.WriteLine(e.StackTrace);
            }

            if (!typeOfAccount.HasValue)
            {
                Console.WriteLine("Terminating process, exiting to main menu");
                return null; //means return to main menu
            }

            while (true)
            {
                try
                {
                    string tempMessage = "Please type in the amount you wish to "
                    + withdrawOrDep.ToString() + ": (note must be positive, use decimals to indicate seperation)";

                    amountToWithdraw = FloatAmountUserInput(tempMessage);

                    if (amountToWithdraw == null)
                    {
                        Console.WriteLine("Terminating process and exiting to main menu");
                        return null;
                    }

                    if (withdrawOrDep == withdrawOrDepositEnum.withdraw)
                    {
                        if (!backendClass.MaxLimitTransactions(typeOfAccount.Value, amountToWithdraw.Value, accountNumber))
                        {
                            throw new ArgumentException("Amount being used is too high for the " + typeOfAccount.Value.ToString() + " account");
                        }
                    }

                    tempMessage = "Is this the correct " +
                    "amount you wish to " + withdrawOrDep.ToString() + ": " + amountToWithdraw.Value + " [y]es or [n]o";

                    bool? checkValueInt = ClarifyUserInput(tempMessage);

                    switch (checkValueInt)
                    {
                        case true:
                            break; //only other break from while loop
                        case false:
                            throw new ArgumentException("Please enter a new account value");
                        case null:
                            Console.WriteLine("Terminating process exiting to main menu");
                            return null;
                    }

                    break;
                }
                catch (ArgumentException e)
                {
                    Console.WriteLine(e.Message);
                }
                catch (NullReferenceException e)
                {
                    Console.WriteLine(e.Message);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.StackTrace);
                }
            }
            


            if (withdrawOrDep.Equals(withdrawOrDepositEnum.withdraw))
            {
                backendClass.WithdrawFromAccount(accountNumber, amountToWithdraw.Value, typeOfAccount.Value);
            }
            else if(withdrawOrDep.Equals(withdrawOrDepositEnum.deposit))
            {
                backendClass.DepositeToAccount(accountNumber, amountToWithdraw.Value, typeOfAccount.Value);
            }
            else
            {
                Console.WriteLine("please check code, error with withdraw or deposit name");
            }

            while (true)
            {
                Console.WriteLine("Please enter q to return to main menu");

                string? userInput = Console.ReadLine().ToLower().Trim();
                if (userInput == null)
                {
                    Console.WriteLine("please enter a valid value");
                }
                else if (userInput == "q")
                {
                    return true;
                }
            }

        }

        /**
         * This method ...
         * 
         * @params
         * TODO set limit for the amount to be transferred
         * @return
         */
        private void TransferToAnotherAccount()
        {
            int? accountNumberToTransferFrom = null;
            int? accountNumberToTransferTo = null;
            float? amountToTransfer = null;
            accountTypeEnum? typeOfAccountToTransferFrom = null;
            accountTypeEnum? typeOfAccountToTransferTo = null;

            //TODO all the true statements
            while (true)
            {
                try
                {
                    PrintTitle();

                    accountNumberToTransferFrom = UserAccountInput("Please enter the account number to transfer funds from");
                    if (!accountNumberToTransferFrom.HasValue)
                    {
                        Console.WriteLine("Transfer not completed, exiting to main menu");
                        return;
                    }

                    bool? isCorrect = ClarifyUserInput("Is this the correct account number?");

                    if(!isCorrect.HasValue)
                    {
                        Console.WriteLine("Transfer not completed, exiting to main menu");
                        return;
                    }
                    
                    if (!backendClass.CheckIfAccountExists(accountNumberToTransferFrom.Value))
                    {
                        throw new ArgumentException("Please enter a new account value, could not find the original");
                    }

                    switch (isCorrect)
                    {
                        case true:
                            break; //only other break from while loop
                        case false:
                            throw new ArgumentException("Please enter a new account value");
                        case null:
                            Console.WriteLine("Terminating process exiting to main menu");
                            return;
                    }

                    

                    break;
                }
                catch (ArgumentException e)
                {
                    Console.WriteLine(e.Message);
                }
                catch (NullReferenceException e)
                {
                    Console.WriteLine(e.Message);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.StackTrace);
                }

            }

            while(true)
            {
                PrintTitle();
                try
                {
                    accountNumberToTransferTo = UserAccountInput("Please enter the account number to transfer funds to");
                    if (!accountNumberToTransferTo.HasValue)
                    {
                        Console.WriteLine("Transfer not completed, exiting to main menu");
                        return;
                    }

                    if (backendClass.CheckIfAccountExists(accountNumberToTransferTo.Value) == false)
                    {
                        throw new ArgumentException("Please enter a new account value, could not find the original");
                    }

                    bool? isCorrect = ClarifyUserInput("Is this the correct account number to transfer funds to? [y]es/[n]o");

                    if (!isCorrect.HasValue)
                    {
                        Console.WriteLine("Transfer not completed, exiting to main menu");
                        return;
                    }

                    switch (isCorrect)
                    {
                        case true:
                            break; //only other break from while loop
                        case false:
                            throw new ArgumentException("Please enter a new account value");
                        case null:
                            Console.WriteLine("Terminating process exiting to main menu");
                            return;
                    }

                    

                    break;
                }
                catch (ArgumentException e)
                {
                    Console.WriteLine("Error occured, Terminating process and exiting to main menu");
                    Console.WriteLine(e.Message);
                }
                catch (NullReferenceException e)
                {
                    Console.WriteLine("Error occured, Terminating process and exiting to main menu");
                    Console.WriteLine(e.Message);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.StackTrace);
                }
            }

            typeOfAccountToTransferFrom = TypeOfAccountUserInput("Please select the type of account to transfer from");
            if(!typeOfAccountToTransferFrom.HasValue)
            {
                Console.WriteLine("Transfer not completed, exiting to main menu");
                return;
            }

            typeOfAccountToTransferTo = TypeOfAccountUserInput("Please select the type of account to transfer to");
            if (!typeOfAccountToTransferTo.HasValue)
            {
                Console.WriteLine("Transfer not completed, exiting to main menu");
                return;
            }

            while(true)
            {
                PrintTitle();
                try
                {
                    amountToTransfer = FloatAmountUserInput("Please enter the amount to transfer [amount must be positive]: ");
                    if (!amountToTransfer.HasValue)
                    {
                        Console.WriteLine("Transfer not completed, exiting to main menu");
                        return;
                    }

                    
                    if (!backendClass.MaxLimitTransactions(typeOfAccountToTransferFrom.Value, amountToTransfer.Value, accountNumberToTransferFrom.Value))
                    {
                        throw new ArgumentException("Amount being used is too high for the " + typeOfAccountToTransferFrom.Value.ToString() + " account");
                    }

                    bool? isCorrect = ClarifyUserInput("Is this the correct amount to transfer [y]es/[n]o?");

                    if (!isCorrect.HasValue)
                    {
                        Console.WriteLine("Transfer not completed, exiting to main menu");
                        return;
                    }

                    switch (isCorrect)
                    {
                        case true:
                            break; //only other break from while loop
                        case false:
                            throw new ArgumentException("Please enter a new account value");
                        case null:
                            Console.WriteLine("Terminating process exiting to main menu");
                            return;
                    }
 

                    break;
                }
                catch (ArgumentException e)
                {
                    Console.WriteLine("Error occured, Terminating process and exiting to main menu");
                    Console.WriteLine(e.Message);
                }
                catch (NullReferenceException e)
                {
                    Console.WriteLine("Error occured, Terminating process and exiting to main menu");
                    Console.WriteLine(e.Message);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.StackTrace);
                }
            } 

            if( backendClass.TransferFunds(accountNumberToTransferFrom.Value, 
                accountNumberToTransferTo.Value, amountToTransfer.Value, typeOfAccountToTransferFrom.Value, 
                typeOfAccountToTransferTo.Value) )
            {
                Console.WriteLine("Successful transfer");
            }
            else
            {
                Console.WriteLine("Unsuccessful transfer");
            }

            while (true)
            {
                Console.WriteLine("Please enter q to return to main menu");

                string? userInput = Console.ReadLine().ToLower().Trim();
                if (userInput == null)
                {
                    Console.WriteLine("please enter a valid value");
                }
                else if (userInput == "q")
                {
                    return;
                }

            }
        }


        //TODO User input view account details, disable account, or activiate account, and exit
        //2
        /**
         * This method ...
         * 
         * @params
         * 
         * @return
         */
        private void ViewAllAccounts()
        {
            PrintTitle();

            List<JSONStructure>? newList = backendClass.ViewAllAccountDetails();
            int count = 1;
            if(newList == null)
            {
                Console.WriteLine("Error retrieving values, returning to main menu");
            }

            else
            {PrintTitle();
                foreach(JSONStructure item in newList)
                {
                    Console.WriteLine("Item number (order of item in print out of accounts): " + count);
                    Console.WriteLine("Account number is: " + item.accountNumber);
                    Console.WriteLine("First name of user is: " + item.firstName);
                    Console.WriteLine("Last name of user is: " + item.lastName);
                    Console.WriteLine("User name of user is: " + item.userName);
                    Console.WriteLine("Password of user is: " + item.userPassword);
                    Console.WriteLine("Saving account balance of user is: " + item.savingAccountBalance);
                    Console.WriteLine("Checking account balance of user is: " + item.checkingAccountBalance);
                    Console.WriteLine("Investment account balance of user is: " + item.investmentAccountBalance);
                    Console.WriteLine("User login attempts made is: " + item.numberOfAttempts);
                    Console.WriteLine("Is the user account unlocked: " + item.isAccountUnlocked);
                    Console.WriteLine("Date the account was created: " + item.accountCreationdate);

                    Console.WriteLine("");
                    count++;
                }
            }

            while (true)
            {
                Console.WriteLine("Please enter q to return to main menu");

                string? userInput = Console.ReadLine().ToLower().Trim();
                if (userInput == null)
                {
                    Console.WriteLine("please enter a valid value");
                }
                else if (userInput == "q")
                {
                    return;
                }
            }
        }

        //TODO when press q exit process and return to main menu
        /**
         * This method ...
         * 
         * @params
         * 
         * @return
         */
        private void ActiviateOrDeactivateAccount(bool activateAccount)
        {
            int accountNumber;

            while(true)
            {
                PrintTitle();

                Console.WriteLine("Please enter the account number you wish to modify: ");
                try
                {
                    string? tempUserInput = Console.ReadLine();
                    if(tempUserInput == null)
                    {
                        throw new NullReferenceException("please enter a valid value");
                    }

                    if( !int.TryParse(tempUserInput, out accountNumber) )
                    {
                        throw new ArgumentException("please enter a positive integer value for the account");
                    }

                    /*
                    if(accountNumber <= 0)
                    {
                    }
                    */
                    if( !backendClass.CheckIfAccountExists(accountNumber))
                    {
                        throw new ArgumentException("account does not exist please enter a valid account number");
                    }


                    Console.WriteLine("Are you sure this is the correct account number to modify? " + accountNumber + " [y]es/[n]o?");
                    string tempString = Console.ReadLine();

                    if (tempString == null)
                    {
                        throw new NullReferenceException("please enter a valid value");
                    }

                    if (!(tempString.Equals("yes") || tempString.Equals("y")))
                    {
                        throw new ArgumentException("not choosen as account balance");
                    }

                    if (!backendClass.CheckIfAccountExists(accountNumber))
                    {
                        throw new ArgumentException("Please enter a new account value, could not find the original");
                    }
                    break;
                }
                catch(ArgumentException e)
                {
                    Console.WriteLine(e.Message);
                }
                catch(NullReferenceException e)
                {
                    Console.WriteLine(e.Message);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.StackTrace);
                }
            }
            
            backendClass.EnableOrDisableAccount(accountNumber, activateAccount);

            while (true)
            {
                Console.WriteLine("Please enter q to return to main menu");

                string? userInput = Console.ReadLine().ToLower().Trim();
                if (userInput == null)
                {
                    Console.WriteLine("please enter a valid value");
                }
                else if (userInput == "q")
                {
                    return;
                }
            }
        }


        /**
         * This method ...
         * 
         * @params
         * 
         * @return
         */
        private void Exit()
        {
            Console.WriteLine("Thank you for using our bank");
            Environment.Exit(0);
        }


        //HELPER METHODS, helps above
        /**
         * This method ...
         * 
         * @params
         * 
         * @return
         */
        private bool? ClarifyUserInput(string messageToPrint)
        {
            while(true)
            {
                try
                {
                    string tempUserInput;

                    Console.WriteLine(messageToPrint);
                    //README: Example Are you sure this is the correct value you want to remove?, press q to exit
                    Console.WriteLine("Press q to terminate process and exit to main menu");

                    tempUserInput = Console.ReadLine().Trim().ToLower();

                    if (tempUserInput == null)
                    {
                        throw new NullReferenceException("Please enter a valid value (yes, no, y, n, or q)");
                    }

                    if (tempUserInput.Equals("yes") || tempUserInput.Equals("y"))
                    {
                        return true;
                    }
                    else if (tempUserInput.Equals("no") || tempUserInput.Equals("n"))
                    {
                        return false;
                    }
                    else if (tempUserInput.Equals("q"))
                    {
                        return null;
                    }
                    else
                    {
                        throw new ArgumentException("Please enter a valid value (yes, no, y, n, or q)");
                    }

                }
                catch (ArgumentException e)
                {
                    Console.WriteLine(e.Message);
                }
                catch (NullReferenceException e)
                {
                    Console.WriteLine(e.Message);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.StackTrace);
                }
            }
   
            
        }


        //TODO
        /**
         * This method ...
         * 
         * @params
         * 
         * @return
         */
        private int? UserAccountInput(string messageToPrint)
        {
            int intToReturn;
            string? tempUserInput;

            while(true)
            {
                try
                {

                    Console.WriteLine(messageToPrint);
                    Console.WriteLine("Press q to exit process and return to main menu");

                    tempUserInput = Console.ReadLine().Trim().ToLower();

                    if (tempUserInput == null)
                    {
                        throw new NullReferenceException("please enter a valid value");
                    }

                    if(tempUserInput == "q")
                    {
                        Console.WriteLine("Exiting process and returning to main menu");
                        return null;
                    }

                    if (!int.TryParse(tempUserInput, out intToReturn))
                    {
                        throw new ArgumentException("please enter a valid account value");
                    }

                    if (!backendClass.CheckIfAccountExists(intToReturn))
                    {
                        throw new ArgumentException("Account not found, please enter another value");
                    }

                    return intToReturn;
                }
                catch (ArgumentException e)
                {
                    Console.WriteLine(e.Message);
                }
                catch (NullReferenceException e)
                {
                    Console.WriteLine(e.Message);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.StackTrace);
                }
            }

        }

        //returns a nullable float type (wrapped class nullable float)
        //TODO fix this to return a float amount or null
        /**
         * This method ...
         * 
         * @params
         * 
         * @return
         */
        private float? FloatAmountUserInput(string messageToPrint)
        {
            float floatToReturn;
            string? tempUserInput;

            while(true)
            {
                try
                {
                    Console.WriteLine(messageToPrint);
                    Console.WriteLine("Press q to quit process and exit to main menu");

                    tempUserInput = Console.ReadLine().Trim().ToLower();

                    if (tempUserInput == null)
                    {
                        throw new NullReferenceException("please enter a valid value (numerical value, use decimals to seperate)");
                    }

                    if (!float.TryParse(tempUserInput, out floatToReturn)) //TODO check try parse return value
                    {
                        throw new ArgumentException("please enter a valid number (numerical value, use decimals to seperate)");
                    }

                    if(floatToReturn < 0)
                    {
                        throw new ArgumentException("Entered value must be a positive number, please enter a new value");
                    }

                    if(tempUserInput == "q")
                    {
                        return null;
                    }

                    return floatToReturn;
                }
                catch (ArgumentException e)
                {
                    Console.WriteLine(e.Message);
                }
                catch (NullReferenceException e)
                {
                    Console.WriteLine(e.Message);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.StackTrace);
                }
            }
        }

        /**
         * This method ...
         * 
         * @params
         * 
         * @return
         */
        private accountTypeEnum? TypeOfAccountUserInput(string messageToPrint)
        {
            accountTypeEnum? returnUserAccountType;
            string? userInput;
            int userEnteredValue;

            while(true)
            {
                try
                {
                    //message is type of account you want to access
                    Console.WriteLine(messageToPrint);
                    Console.WriteLine("1. checking account\n2. savings account\n3. investment account\n4. Quit");
                    Console.WriteLine("Please enter either a numerical value (1, 2, 3) correlation to the account type");

                    userInput = Console.ReadLine().Trim().ToLower();

                    if (userInput == null)
                    {
                        throw new NullReferenceException("please enter a valid value (1-4, or q to quit)");
                    }

                    if (!int.TryParse(userInput, out userEnteredValue))
                    {
                        throw new ArgumentException("please enter a valid value (1-4, or q to quit)");
                    }

                    if (userInput == "q" || userInput == "Q")
                    {
                        Console.WriteLine("returning to main menu");
                        return null;
                    }

                    switch (userEnteredValue)
                    {
                        case 1:
                            returnUserAccountType = accountTypeEnum.checking;
                            return returnUserAccountType;
                        case 2:
                            returnUserAccountType = accountTypeEnum.saving;
                            return returnUserAccountType;
                        case 3:
                            returnUserAccountType = accountTypeEnum.investment;
                            return returnUserAccountType;
                        case 4:
                            Console.WriteLine("returning to main menu");
                            return null;
                        default:
                            throw new ArgumentException("Please enter a value within the range 1-4");
                    }
                }
                catch(ArgumentException e)
                {
                    Console.WriteLine(e.Message);
                }
                catch(NullReferenceException e)
                {
                    Console.WriteLine(e.Message);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.StackTrace);
                }
            }   
        }

        /*
         * This method is a helper for the CreateAccount method
         * @params 
         * string nameType, first name or lastname
         * return of string (person's name) if successful
         */
        private string? CreateAccountHelperGUI(string nameType)
        {
            string? personName = "";
            PrintTitle();
            while (true)
            {
                
                try
                {
                    Console.WriteLine("Please enter the account " + nameType + " or enter q to exit to main menu");

                    personName = Console.ReadLine();

                    if (personName == null || personName.Length < 1)
                    {
                        throw new ArgumentException("invalid value for a name, please enter another value");
                    }

                    if (personName == "Q" || personName == "q")
                    {
                        Console.WriteLine("Terminating process, exiting to main menu");
                        return null;
                    }

                    //TODO can modify to is char if using languages outside of english, regex good for english
                    if (!System.Text.RegularExpressions.Regex.IsMatch(personName, @"^[a-zA-Z]+$"))
                    {
                        throw new ArgumentException("please only include letters in the person's name");
                    }

                    bool? checkInput = ClarifyUserInput("Are you sure this is the correct name of the person? [y]es/[n]o");

                    if(!checkInput.HasValue)
                    {
                        return null;
                    }

                    break;
                }
                catch (ArgumentException e)
                {
                    Console.WriteLine(e.Message);
                }
                catch (NullReferenceException)
                {
                    Console.WriteLine("Please enter a valid value");
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.StackTrace);
                }
            }

            return personName;
        }


        /*
         * This method is a helper for the CreateAccount method, username
         * @params 
         * none
         * return of string (username) if successful
         *readme: magic numbers aern't great but whatever
         */
        private string? CreateAccountHelperUserNameGUI(int AdminOrUserAccount)
        {
            string userName;

            PrintTitle();

            while (true)
            {
                try
                {
                    Console.WriteLine("Please enter the username that for the account or enter q to exit to main menu");

                    userName = Console.ReadLine();
                    if (userName == null)
                    {
                        throw new ArgumentException("please enter a new value, username is null");
                    }

                    if(userName == "q" || userName == "Q")
                    {
                        return null;
                    }

                    if(AdminOrUserAccount == 0)
                    {
                        if (backendClass.CheckIfAccountExists(userName))
                        {
                            throw new ArgumentException("this username already exists please enter a new value");
                        }
                    }
                    else if(AdminOrUserAccount == 1)
                    {
                        if (backendClass.CheckIfAccountExists(userName))
                        {
                            throw new ArgumentException("this username already exists please enter a new value");
                        }
                    }
                    else
                    {
                        throw new ArgumentException("issue with method value");
                    }

                    Console.WriteLine("Are you sure you want this to be the account username [y]es/[n]o?");

                    string? tempString = Console.ReadLine();

                    if (!(tempString.Equals("yes") || tempString.Equals("y"))) //TODO check if logic is correct, if either or don't throw
                    {
                        throw new ArgumentException("not choosen as username");
                    }

                    break;

                }
                catch (ArgumentException e)
                {
                    Console.WriteLine(e.Message);
                    //TODO can change this to generic message
                }
                catch (NullReferenceException)
                {
                    Console.WriteLine("Please enter a valid value");
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.StackTrace);
                }
            }

            return userName;
        }

        /*
         * This method is a helper for the CreateAccount method, creates a password
         * @params 
         * string firstname of user, 
         * string lastname of user
         * return of string (password) if successful
         */
        private string? CreateAccountHelperPassword(string firstName, string lastName)
        {
            string? passWord;

            PrintTitle();

            while (true)
            {
                try
                {
                    Console.WriteLine("Please enter the password for the account, size must be between " + minPasswordLength
                        + " and " + maxPasswordLength + " or enter q to exit to main menu");

                    passWord = Console.ReadLine();

                    //TODO add redex expression that checks for multiple repeating values
                    if (passWord == null)
                    {
                        throw new ArgumentException("password cannot be a null value");
                    }
                    else if (passWord == "q" || passWord == "Q")
                    {
                        return null;
                    }
                    else if (passWord.Length < minPasswordLength || passWord.Length > maxPasswordLength)
                    {
                        throw new ArgumentException("password too short or too long, please choose a new one");
                    }
                    else if (passWord.Contains(firstName) || passWord.Contains(lastName))
                    {
                        throw new ArgumentException("password cannot contain user firstname or lastname");
                    }

                    Console.WriteLine("Are you sure you want this to be the account password [y]es/[n]o?");
                    string? tempString = Console.ReadLine();

                    if (tempString == null)
                    {
                        throw new NullReferenceException("please enter a valid value (yes, y, no, or n)");
                    }

                    if (!(tempString.Equals("yes") || tempString.Equals("y"))) //TODO check if logic is correct, if either or don't throw
                    {
                        throw new ArgumentException("not choosen as password");
                    }

                    break;
                }
                catch (ArgumentException e)
                {
                    Console.WriteLine(e.Message);
                    //TODO can change this to generic message
                }
                catch (NullReferenceException)
                {
                    Console.WriteLine("Please enter a valid value");
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.StackTrace);
                }
            }

            return passWord;
        }

        private float? CreateAccountBalanceHelper(string messageToPrintFloat)
        {
            float? accountBalance;
            string? userInput;

            PrintTitle();

            while (true)
            {
                try
                {
                    accountBalance = FloatAmountUserInput(messageToPrintFloat);

                    if (accountBalance == null)
                    {
                        return null; //returns to main
                    }

                    string? tempString = "Are you sure you want this to be the account balance [y]es/[n]o?";

                    bool? checkValueInt = ClarifyUserInput(tempString); //TODO

                    switch (checkValueInt)
                    {
                        case true:
                            return accountBalance.Value; //only other break from while loop
                        case false:
                            throw new ArgumentException("Please enter a new account value");
                        case null:
                            Console.WriteLine("Terminating process exiting to main menu");
                            return null;
                    }

                }
                catch (ArgumentException e)
                {
                    Console.WriteLine(e.Message);
                }
                catch (NullReferenceException e)
                {
                    Console.WriteLine(e.Message);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.StackTrace);
                }
            }

        }

    }

}
