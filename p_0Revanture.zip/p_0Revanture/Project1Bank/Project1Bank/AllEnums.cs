﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project1Bank
{
    public class AllEnums
    {
        
    }
    public enum withdrawOrDepositEnum
    {
       withdraw,
       deposit
    }
    public enum accountStatusEnum
    {
        disabled,
        enabled,
        underReview
    }
    public enum accountTypeEnum
    { 
        checking,
        saving,
        investment
    }

}
