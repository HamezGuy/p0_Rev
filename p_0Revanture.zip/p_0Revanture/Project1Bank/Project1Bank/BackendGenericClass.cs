﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project1Bank
{
    internal class BackendGenericClass
    {
        protected bool LogTransaction(string p_adminOrUser, string p_messageToLog, int? p_accountNumber = null)
        {
            return true;
        }

        protected void MaxLimitTransactions()
        {

        }
    }
}
