﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project1Bank
{
    public interface IAdminBackendInterface
    {
        public int LoginToAccountAdmin(string userName, string passWord)
        {
            return 0;
        }

        public bool CheckIfUsernameIsOpen(string userName)
        {
            return true;
        }

        public bool CreateNewAccount(string firstName, string lastName, string userName,
            string passWord, float checkingBalance, float savingAccountBalance, float investmentAccountBalance,
            accountStatusEnum accountStatus, string additionalNotes = "")
        {
            return false;
        }

        public bool CheckIfAccountExists(int accountNumber)
        {
            return false;
        }

        public void ViewAllAccountDetails()
        {
        }

        public void WithdrawFromAccount(int accountNumber, float amountToWithdraw, accountTypeEnum typeOfAccount)
        {
        }

        /*
         * 
         * README: while I could put withdraw and deposite in same method, since "money" (program won't be used) is involved its always better to be clearer
         */
        public void DepositeToAccount(int accountNumber, float amountToDeposit, accountTypeEnum typeOfAccount)
        {
        }

        public bool TransferFunds(int accountToTransferFrom, int accountToTransferTo, float amountToTransfer, accountTypeEnum typeOfAccountTransferFrom,
            accountTypeEnum typeOfAccountTransferTo)
        {
            return true;
        }

        public void EnableOrDisableAccount(int accountNumber, accountStatusEnum enableOrDisable)
        {
        }  

    }
}
