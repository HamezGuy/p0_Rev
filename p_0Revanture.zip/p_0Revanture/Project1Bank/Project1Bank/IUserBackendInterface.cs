﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project1Bank
{
    public interface IUserBackendInterface
    {


        public bool CheckBalance()
        {
            return false;
        }

        public int WithdrawMoney(float amountToWithdraw, accountTypeEnum accountToWithdrawFrom)
        {
            return 0;
        }

        public int DepositMoney(float amountToDeposit, accountTypeEnum accountToDepositTo)
        {
            return 0;
        }

        public bool TransferMoney(int otherAccountDetails, float amountToTransfer, accountTypeEnum accountTypeToTransferFrom,
        accountTypeEnum typeOfAccountToTransferTo)
        {
            return true;
        }

        public List<string>? ViewLastTenInteractions()
        {
            return null;
        }

        public bool CheckIfPasswordsMatch(string passwordToCheck)
        {
            return false;
        }
        /*
         * 
         * TODO decide if this should console.log or not 
         */
        public bool ChangePassword(string stringPasswordToChangeTo,int minPasswordLength, int maxPasswordLength)
        {
            return true;
        }

        public int LoginAttempt(string userName, string passWord)
        {
            return 0;
        }

        public bool CheckIfAccountExists(string userName)
        {
            return false;
        }

    }
}
