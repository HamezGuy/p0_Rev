﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
 * This class is a simple JSON object w/ information about basic account information, basically a struct
 *  Written by James Gui 05/24/2022
 */
namespace Project1Bank
{
    [Serializable] //README, do we need system? I had to in unity, check if i can just user serializable or system.seralizable
    public class JSONStructure
    {
        public string firstName { get; set; }
        public string lastName { get; set; }
        public string userName { get; set; }
        public string userPassword { get; set; }
        public float savingAccountBalance { get; set; }
        public float checkingAccountBalance { get; set; }
        public float investmentAccountBalance { get; set; }
        public int accountNumber { get; set; }
        public bool isAccountUnlocked   { get; set; }
        public int numberOfAttempts { get; set; }
        public List<string>? pastTenTransactions { get; set; }

        public DateTime accountCreationdate { get; set; }
        //TODO impliment logging of transactions via serilog

        public JSONStructure(string firstName, string lastName, string userName, string userPassword, float savingAccountBalance, 
            float checkingAccountBalance, float investmentAccountBalance, 
            int accountNumber, bool isAccountUnlocked, int numberOfAttempts,
            DateTime accountCreationdate, List<string>? pastTenTransactions = null) //note this is mainly to remember the params
        {
            this.firstName = firstName;
            this.lastName = lastName;
            this.userName = userName;
            this.userPassword = userPassword;
            this.savingAccountBalance = savingAccountBalance;
            this.checkingAccountBalance = checkingAccountBalance;
            this.investmentAccountBalance = investmentAccountBalance; 
            this.pastTenTransactions = pastTenTransactions;
            this.isAccountUnlocked = isAccountUnlocked;
            this.numberOfAttempts = numberOfAttempts;
            this.accountNumber = accountNumber;
            this.accountCreationdate = accountCreationdate;
        }



    }

    [Serializable]
    public class AdminJSONStructure
    {
        public AdminJSONStructure(string firstName, string lastName, string userName, string userPassword, int numberOfLoginAttempts, int accountNumber, DateTime creationDate)
        {//note this is mainly so i can remember all the params without visiting this class again (abusing intellisense)
            this.firstName = firstName;
            this.lastName = lastName;
            this.userName = userName;
            this.userPassword = userPassword;
            this.numberOfLoginAttempts = numberOfLoginAttempts;
            this.accountNumber = accountNumber;
            this.creationDate = creationDate;
        }

        public string firstName { get; set; }
        public string lastName { get; set; }
        public string userName { get; set; }
        public string userPassword { get; set; }
        public int accountNumber { get; set; }
        public int numberOfLoginAttempts  { get; set; }
        public DateTime creationDate { get; set; }

        
    }
}
