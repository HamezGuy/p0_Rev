﻿// See https://aka.ms/new-console-template for more information
/*
 * TODO: need to add additional features, try to test edge cases
 * What the fuck is this new format? Basically a giant main statement?
 * Written by James Gui 05/24/2022
 * 
 * References: none
 *  
 * This class is resposible for taking user input and running the bank statement
 * 
 * README: While i normally use interfaces for development w/ groups, this is a solo project
 * and a quick one so it isn't practicial to add it
 * 
 * params?????????? no main function
 */
using Project1Bank;

//fields 
string? userInput;
int userInputInt;

UserGUI userInterface = new UserGUI();
AdminGUI adminInterface = new AdminGUI();

while(true)
{
    Console.Clear();
    Console.WriteLine(@"
████████ ███████ ███████ ████████ ██████   █████  ███    ██ ██   ██ 
   ██    ██      ██         ██    ██   ██ ██   ██ ████   ██ ██  ██  
   ██    █████   ███████    ██    ██████  ███████ ██ ██  ██ █████   
   ██    ██           ██    ██    ██   ██ ██   ██ ██  ██ ██ ██  ██  
   ██    ███████ ███████    ██    ██████  ██   ██ ██   ████ ██   ██ 
                                                                    
                                                                    
        ");
    Console.WriteLine("Welcome to the Test Bank Project.");
    Console.WriteLine("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
    Console.WriteLine("Please enter a selection below to log in, (enter 1, 2, or 3)");
    Console.WriteLine("1. Log into a Admin Account");
    Console.WriteLine("2. Log into a User Account");
    Console.WriteLine("3. Exit");

    try
    {
        userInput = Console.ReadLine();

        if (userInput == null)
        {
            throw new NullReferenceException("No input detected, please enter a valid value from above");
        }

        if(!int.TryParse(userInput, out userInputInt))
        {
            throw new ArgumentException("Please enter a valid value (1, 2, or 3)");
        }

        switch(userInputInt)
        {
            case 1:
                adminInterface.AdminLogin();
                break;

            case 2:
                userInterface.UserLoginAndInitialization();
                break;

            case 3:
                Console.WriteLine("Thank you for using our program, see you again");
                Environment.Exit(0);
                return;

            default:
                throw new ArgumentException("Please enter either 1, 2, or 3");

        }
    }
    catch(ArgumentException e)
    {
        Console.WriteLine(e.Message);
    }
    catch (NullReferenceException e)
    {
        Console.WriteLine(e.Message);
    }
    catch (Exception e)
    {
        Console.WriteLine(e.StackTrace);
    }

}



