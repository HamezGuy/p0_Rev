﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.Json;
using System.Text.Json.Serialization;
using Newtonsoft.Json;
using JsonSerializer = System.Text.Json.JsonSerializer;
//using Microsoft.Extensions.Logging; - ask which ones to use
using Serilog;
using System.Data.SqlClient;


namespace Project1Bank
{
    /*
     * This class is responsible for data management, to and from JSON storage
     * Has GetFromJSON and WriteToJSON methods
     * Written by James Gui 05/24/2022
     * 
     * Refernces: https://passos.com.au/converting-json-object-into-c-list/
     * https://docs.microsoft.com/en-us/dotnet/standard/serialization/system-text-json-how-to?pivots=dotnet-6-0
     * 
     * README: no interface, don't want to backtrack and make one
     */

    //TODO for points I can use JSON w/ async ex. Ienumerator & saves. 
    public class ToAndFromJSON
    {
        //fields
        static string adminFileLocation = "D:/RevStuff/RevProjects/Project1/Project1Bank/adminAccount.txt";
        static string userFileLocation = "D:/RevStuff/RevProjects/Project1/Project1Bank/userAccountsStorage.txt";
        StreamReader streamReader;
        string? fileStringUser = File.ReadAllText(userFileLocation);
        string? fileStringAdmin = File.ReadAllText(adminFileLocation);
        string fileLocationSQL = @"server = .\JAMES_INSTANCE; database = bankingDB; integrated security = true";



        /*constructor
         *@params
         *none
         *
         *initializes the streamreader to the file location
         *initializes the (string) file with the contents of the json
         *throws error if not found
         */
        public ToAndFromJSON()
        {
            try
            {
                //fileStringUser = File.ReadAllText(userFileLocation);
                //fileStringAdmin = File.ReadAllText(adminFileLocation);

                Log.Logger = new LoggerConfiguration().WriteTo.File(@"D://RevStuff//RevProjects//Project1//Project1Bank//SerilogData.txt").CreateLogger();
                
            }
            catch(Exception e)
            {
                Log.Error(e.ToString());
            }
        }

        /*
         * This method writes objects in the list to JSON storage (static location above). 
         * @params
         * List<JSONStructure> JSONList, a list of type JSONStructure to store as JSON objects
         * @return
         * bool, true indicates success, false indicates failure
         */
        public bool WriteToJSON(JSONStructure accountToAdd)
        {
            SqlConnection connection = new SqlConnection(fileLocationSQL);
            SqlCommand sqlCommand = new SqlCommand("INSERT INTO tbl_AccountsBaseDetails ([accountNumber], [firstName], [lastName], [userName], [userPassword], [savingAccountBalance]," +
                    "[checkingAccountBalance], [investmentAccountBalance], [numberOfAttempts], " +
                    "[accountStatus], [dateCreated]) VALUES(@accountNumber, @firstName, @lastName, @userName, @userPassword, @savingAccountBalance," +
                    "@checkingAccountBalance, @investmentAccountBalance, @numberOfAttempts, @accountStatus, @dateCreated )", connection);

            sqlCommand.Parameters.AddWithValue("@accountNumber", System.Data.SqlDbType.Int).Value = accountToAdd.accountNumber;
            sqlCommand.Parameters.AddWithValue("@firstName", System.Data.SqlDbType.VarChar).Value = accountToAdd.firstName;
            sqlCommand.Parameters.AddWithValue("@lastName", System.Data.SqlDbType.VarChar).Value = accountToAdd.lastName;
            sqlCommand.Parameters.AddWithValue("@userName", System.Data.SqlDbType.VarChar).Value = accountToAdd.userName;
            sqlCommand.Parameters.AddWithValue("@userPassword", System.Data.SqlDbType.VarChar).Value = accountToAdd.userPassword;
            sqlCommand.Parameters.AddWithValue("@savingAccountBalance", System.Data.SqlDbType.Float).Value = accountToAdd.savingAccountBalance;
            sqlCommand.Parameters.AddWithValue("@checkingAccountBalance", System.Data.SqlDbType.Float).Value = accountToAdd.checkingAccountBalance;
            sqlCommand.Parameters.AddWithValue("@investmentAccountBalance", System.Data.SqlDbType.Float).Value = accountToAdd.investmentAccountBalance;
            sqlCommand.Parameters.AddWithValue("@numberOfAttempts", System.Data.SqlDbType.Int).Value = accountToAdd.numberOfAttempts;
            sqlCommand.Parameters.AddWithValue("@accountStatus", System.Data.SqlDbType.Bit).Value = accountToAdd.isAccountUnlocked;
            sqlCommand.Parameters.AddWithValue("@dateCreated", System.Data.SqlDbType.DateTime).Value = accountToAdd.accountCreationdate;

            try
            {
                if (CheckIfAccountExists(accountToAdd.accountNumber) == true)
                {
                    throw new Exception();
                }

                connection.Open();

                sqlCommand.ExecuteNonQuery();

                if(!CreateNewTransactionTable(accountToAdd.accountNumber, connection))
                {
                    throw new Exception();
                }
            }
            catch(Exception e)
            {
                Log.Error(e.ToString());
                return false;
            }
            finally
            {
                connection.Close();
            }

            return true;

        }

        /*
         * 
         * 
         * @return
         * bool, true indicates success, false indicates failure
         */
        public bool WriteToJSON(AdminJSONStructure adminAccountToAdd)
        {
            SqlConnection connection = new SqlConnection(fileLocationSQL);

            SqlCommand sqlCommand = new SqlCommand("insert into tbl_AdminAccounts ([firstName]," +
                "[lastName], [userName], [passWord], [accountNumber], [numberOfLoginAttempts]," +
                "[dateTime]) values(@firstName, @lastName, @userName, @password, @accountNumber," +
                "@numberOfLoginAttempts, @dateTime)", connection);

            sqlCommand.Parameters.AddWithValue("@firstName", System.Data.SqlDbType.VarChar).Value = adminAccountToAdd.firstName;
            sqlCommand.Parameters.AddWithValue("@lastName", System.Data.SqlDbType.VarChar).Value = adminAccountToAdd.lastName;
            sqlCommand.Parameters.AddWithValue("@userName", System.Data.SqlDbType.VarChar).Value = adminAccountToAdd.userName;
            sqlCommand.Parameters.AddWithValue("@passWord", System.Data.SqlDbType.VarChar).Value = adminAccountToAdd.userPassword;
            sqlCommand.Parameters.AddWithValue("@accountNumber", System.Data.SqlDbType.Int).Value = adminAccountToAdd.accountNumber;
            sqlCommand.Parameters.AddWithValue("@fnumberOfLoginAttempts", System.Data.SqlDbType.Int).Value = adminAccountToAdd.numberOfLoginAttempts;
            sqlCommand.Parameters.AddWithValue("@dateTime", System.Data.SqlDbType.DateTime).Value = adminAccountToAdd.creationDate;

            try
            {
                
                if (CheckIfAccountExistsAdmin(adminAccountToAdd.accountNumber) == true)
                {
                    throw new Exception();
                }
                
                connection.Open();
                
                sqlCommand.ExecuteNonQuery();
               
                return true;
            }
            catch(IOException e)
            {
                Log.Error(e.ToString());
                return false;
            }
            catch (Exception e)
            {
                Log.Error(e.ToString());
                return false;
            }
            finally
            {
                connection.Close();
            }


        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="accountToUpdate"></param>
        /// <returns></returns>
        public bool UpdateSQL(JSONStructure accountToUpdate)
        {
            Console.WriteLine("executing");
            SqlConnection connection = new SqlConnection(fileLocationSQL);

            SqlCommand sqlCommand = new SqlCommand("update tbl_AccountsBaseDetails set firstName = @_firstName, numberOfAttempts = @_numberOfAttempts, lastName = @_lastName," +
                "userPassword = @_userPassword, savingAccountBalance = @_savingAccountBalance, checkingAccountBalance = @_checkingAccountBalance, investmentAccountBalance = @_investmentAccountBalance," +
                "accountStatus = @_accountStatus, userName = @_userName" +
                " where accountNumber = @_accountNumber", connection); //note will never change accountNumber, or the date created

            /*
             * "update tbl_AccountsBaseDetails set firstName = @firstName," +
                "lastName = @lastName, userName = @userName, userPassword = @userPassword, savingAccountBalance = @savingAccountBalance," +
                "checkingAccountBalance = @checkingAccountBalance, investmentAccountBalance = @investmentAccountBalance," +
                "numberOfAttempts = @numberOfAttempts, accountStatus = @accountStatus, dateCreated = @dateCreated" +
                " where accountNumber = @accountNumber"
            */
            sqlCommand.Parameters.AddWithValue("@_accountNumber", System.Data.SqlDbType.Int).Value = accountToUpdate.accountNumber;
            sqlCommand.Parameters.AddWithValue("@_firstName", System.Data.SqlDbType.VarChar).Value = accountToUpdate.firstName;
            sqlCommand.Parameters.AddWithValue("@_lastName", System.Data.SqlDbType.VarChar).Value = accountToUpdate.lastName;
            sqlCommand.Parameters.AddWithValue("@_userName", System.Data.SqlDbType.VarChar).Value = accountToUpdate.userName;
            sqlCommand.Parameters.AddWithValue("@_userPassword", System.Data.SqlDbType.VarChar).Value = accountToUpdate.userPassword;
            sqlCommand.Parameters.AddWithValue("@_savingAccountBalance", System.Data.SqlDbType.Float).Value = accountToUpdate.savingAccountBalance;
            sqlCommand.Parameters.AddWithValue("@_checkingAccountBalance", System.Data.SqlDbType.Float).Value = accountToUpdate.checkingAccountBalance;
            sqlCommand.Parameters.AddWithValue("@_investmentAccountBalance", System.Data.SqlDbType.Float).Value = accountToUpdate.investmentAccountBalance;
            sqlCommand.Parameters.AddWithValue("@_numberOfAttempts", System.Data.SqlDbType.Int).Value = accountToUpdate.numberOfAttempts;
            sqlCommand.Parameters.AddWithValue("@_accountStatus", System.Data.SqlDbType.Bit).Value = accountToUpdate.isAccountUnlocked;
            sqlCommand.Parameters.AddWithValue("@dateCreated", System.Data.SqlDbType.DateTime).Value = accountToUpdate.accountCreationdate;
            sqlCommand.Parameters.AddWithValue("@accountNumber", System.Data.SqlDbType.Int).Value = accountToUpdate.accountNumber;

            try
            {
                if (CheckIfAccountExists(accountToUpdate.accountNumber) == false)
                {
                    throw new Exception();
                }

                connection.Open();
                sqlCommand.ExecuteNonQuery();


                return true;
            }
            catch (IOException e)
            {
                Log.Error(e.ToString());
                return false;
            }
            catch (Exception e)
            {
                Log.Error(e.ToString());
                return false;
            }
            finally
            {
                connection.Close();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="adminAccountToUpdate"></param>
        /// <returns></returns>
        public bool UpdateSQL(AdminJSONStructure adminAccountToUpdate)
        {

            SqlConnection connection = new SqlConnection(fileLocationSQL);

            SqlCommand sqlCommand = new SqlCommand("update tbl_AdminAccounts set firstName = @firstName," +
                "lastName = @lastName, userName = @userName, passWord = @passWord," +
                "numberOfLoginAttempts = @numberOfLoginAttempts," +
                "dateTime = @dateTime where accountNumber = @accountNumber", connection);

            sqlCommand.Parameters.AddWithValue("@firstName", System.Data.SqlDbType.VarChar).Value = adminAccountToUpdate.firstName;
            sqlCommand.Parameters.AddWithValue("@lastName", System.Data.SqlDbType.VarChar).Value = adminAccountToUpdate.lastName;
            sqlCommand.Parameters.AddWithValue("@userName", System.Data.SqlDbType.VarChar).Value = adminAccountToUpdate.userName;
            sqlCommand.Parameters.AddWithValue("@passWord", System.Data.SqlDbType.VarChar).Value = adminAccountToUpdate.userPassword;
            sqlCommand.Parameters.AddWithValue("@accountNumber", System.Data.SqlDbType.Int).Value = adminAccountToUpdate.accountNumber;
            sqlCommand.Parameters.AddWithValue("@fnumberOfLoginAttempts", System.Data.SqlDbType.Int).Value = adminAccountToUpdate.numberOfLoginAttempts;
            sqlCommand.Parameters.AddWithValue("@dateTime", System.Data.SqlDbType.DateTime).Value = adminAccountToUpdate.creationDate;

            try
            {
                if (CheckIfAccountExistsAdmin(adminAccountToUpdate.accountNumber) == false)
                {
                    throw new Exception();
                }

                connection.Open();
                sqlCommand.ExecuteNonQuery();

                return true;
            }
            catch (IOException e)
            {
                Log.Error(e.ToString());
                return false;
            }
            catch (Exception e)
            {
                Log.Error(e.ToString());
                return false;
            }
            finally
            {
                connection.Close();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="accountNumber"></param>
        /// <returns></returns>
        public bool CheckIfAccountExists(int accountNumber)
        {
            SqlConnection connection = new SqlConnection(fileLocationSQL);
            SqlCommand cmd = new SqlCommand("Select count(*) from tbl_AccountsBaseDetails where accountNumber = @accountNumber", connection);
            cmd.Parameters.AddWithValue("@accountNumber", System.Data.SqlDbType.Int).Value = accountNumber;

            try
            {
                connection.Open();//TODO in the future i can play around w/ async
                int accountExists = Convert.ToInt32(cmd.ExecuteScalar());

                if(accountExists == 0 || accountExists == null)
                {
                    return false;
                }

                return true;
            }
            catch (Exception e)
            {
                return false;
            }
            finally
            {
                connection.Close();
            }
           
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="userName"></param>
        /// <returns></returns>
        public bool CheckIfAccountExists(string userName)
        {
            SqlConnection connection = new SqlConnection(fileLocationSQL);
            SqlCommand cmd = new SqlCommand("Select count(*) from tbl_AccountsBaseDetails where userName = @userName", connection);
            cmd.Parameters.AddWithValue("@userName", System.Data.SqlDbType.VarChar).Value = userName;

            try
            {
                connection.Open();//TODO in the future i can play around w/ async
                int accountExists = Convert.ToInt32(cmd.ExecuteScalar());

                if (accountExists == 0 || accountExists == null)
                {
                    return false;
                }

                return true;
            }
            catch (Exception e)
            {
                return false;
            }
            finally
            {
                connection.Close();
            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="accountNumber"></param>
        /// <returns></returns>
        public bool CheckIfAccountExistsAdmin(int accountNumber)
        {
            SqlConnection connection = new SqlConnection(fileLocationSQL);
            SqlCommand cmd = new SqlCommand("Select count(*) from tbl_AdminAccounts where accountNumber = @accountNumber", connection);
            cmd.Parameters.AddWithValue("@accountNumber", System.Data.SqlDbType.Int).Value = accountNumber;

            
            try
            {
                connection.Open();//TODO in the future i can play around w/ async

                var accountExists = cmd.ExecuteScalar();

                if (accountExists == null)
                {
                    return false;
                }

                return true;
            }
            catch (Exception e)
            {
                return false;
            }
            finally
            {
                connection.Close();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="userName"></param>
        /// <returns></returns>
        public bool CheckIfAccountExistsAdmin(string userName)
        {
            SqlConnection connection = new SqlConnection(fileLocationSQL);
            SqlCommand cmd = new SqlCommand("select count(*) from tbl_AdminAccounts where userName = @userName", connection);
            cmd.Parameters.AddWithValue("@userName", System.Data.SqlDbType.VarChar).Value = userName;

            try
            {
                connection.Open();//TODO in the future i can play around w/ async
                int accountExists = Convert.ToInt32(cmd.ExecuteScalar());
                if (accountExists == 0)
                {
                    return false;
                }

                return true;
            }
            catch (Exception e)
            {
                return false;
            }
            finally
            {
                connection.Close();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public int? ReturnMaxAccountNumber()
        {
            SqlConnection connection = new SqlConnection(fileLocationSQL);
            SqlCommand cmd = new SqlCommand("select max(accountNumber) from tbl_AccountsBaseDetails", connection);

            try
            {
                connection.Open();

                return Convert.ToInt32(cmd.ExecuteScalar());
            }
            catch(Exception)
            {
                return null;
            }
            finally
            {
                connection.Close();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public int? ReturnMaxAccountNumberAdmin()
        {
            SqlConnection connection = new SqlConnection(fileLocationSQL);
            SqlCommand cmd = new SqlCommand("Select count(*) from tbl_AdminAccounts where accountNumber = @accountNumber", connection);


            try
            {
                connection.Open();

                return Convert.ToInt32(cmd.ExecuteScalar());
            }
            catch (Exception)
            {
                return null;
            }
            finally
            {
                connection.Close();
            }
        }
        
        /*
         * 
         * 
         * @return
         * List of type JSONStructure on success, null on failure
         */
        public JSONStructure? GetFromJSON(int accountNumber)
        {
            //TODO
            JSONStructure? account = null;
            SqlDataReader readRecord;
            SqlConnection connection = new SqlConnection(fileLocationSQL);
            SqlCommand sqlCommand = new SqlCommand("select * from tbl_AccountsBaseDetails where accountNumber = @accountNumber", connection);
            sqlCommand.Parameters.AddWithValue("@accountNumber", accountNumber); //p_empNo Tablename);

            try
            {
                connection.Open();
                readRecord = sqlCommand.ExecuteReader();

                if (readRecord.Read())
                {
                    //TODO list of 10 transactions
                    //int accountNumberFromJSON = Convert.ToInt32(readRecord[0]);
                    string firstName = Convert.ToString(readRecord[1]);
                    string lastName = Convert.ToString(readRecord[2]);
                    string userName = Convert.ToString(readRecord[3]);
                    string password = Convert.ToString(readRecord[4]);
                    float savingAccount = Convert.ToSingle(readRecord[5]);
                    float checkingAccount = Convert.ToSingle(readRecord[6]);
                    float investmentAccountBalance = Convert.ToSingle(readRecord[7]);
                    int numberOfAttempts = Convert.ToInt32(readRecord[8]);
                    bool accountStatus = Convert.ToBoolean(readRecord[9]);
                    DateTime dateCreated = Convert.ToDateTime(readRecord[10]);

                    account = new JSONStructure(firstName, lastName, userName, password, savingAccount, checkingAccount,
                        investmentAccountBalance, accountNumber, accountStatus, numberOfAttempts, dateCreated);

                    readRecord.Close(); //make sure to close reader as well
                    connection.Close();
                }
                else
                {
                    throw new ArgumentNullException();
                }

                return account;
            }
            catch (NullReferenceException e)
            {
                //usually means new account
                //Console.WriteLine(e.StackTrace);
                return null;
            }
            catch (Exception e)
            {
                //Console.WriteLine(e.StackTrace);
                return null;
            }
            finally
            {
                connection.Close();
            }


        }


        /*
         * 
         * 
         * @return
         * List of type JSONStructure on success, null on failure
         */
        public AdminJSONStructure? GetFromJSONAdmin(int accountNumber)
        {
            AdminJSONStructure? account;
            SqlDataReader readRecord;
            SqlConnection connection;

            try
            {
                if (fileStringAdmin == null)
                {
                    throw new NullReferenceException();
                }

                connection = new SqlConnection(fileLocationSQL);
                SqlCommand sqlCommand = new SqlCommand("select * from tbl_AdminAccounts where accountNumber = @accountNumber", connection);
                sqlCommand.Parameters.AddWithValue("@accountNumber", accountNumber); //p_empNo Tablename);

                connection.Open();
                readRecord = sqlCommand.ExecuteReader();

                if (readRecord.Read())
                {
                    string firstName = Convert.ToString(readRecord[0]);
                    string lastName = Convert.ToString(readRecord[1]);
                    string userName = Convert.ToString(readRecord[2]);
                    string passWord = Convert.ToString(readRecord[3]);
                    int numberOfLoginAttempts = Convert.ToInt32(readRecord[5]);
                    DateTime dateCreated = Convert.ToDateTime(readRecord[6]);

                    account = new AdminJSONStructure(firstName, lastName, userName, passWord, numberOfLoginAttempts, accountNumber, dateCreated);
                }
                else
                {
                    throw new NullReferenceException();
                }

                readRecord.Close();
                connection.Close();
                return account;
            }
            catch (NullReferenceException e)
            {
                //TODO serilog
                //Console.WriteLine(e.StackTrace);
                return null;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.StackTrace);
                return null;
            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="userName"></param>
        /// <returns></returns>
        public JSONStructure? GetFromJSON(string userName)
        {
            //TODO
            JSONStructure? account;
            SqlDataReader readRecord;
            SqlConnection connection;

            try
            {

                connection = new SqlConnection(fileLocationSQL);
                SqlCommand sqlCommand = new SqlCommand("select * from tbl_AccountsBaseDetails where userName = @userName", connection);
                sqlCommand.Parameters.AddWithValue("@userName", System.Data.SqlDbType.VarChar).Value = userName; 

                connection.Open();
                readRecord = sqlCommand.ExecuteReader();


                if (readRecord.Read())
                {
                    
                    //TODO list of 10 transactions
                    int accountNumber = Convert.ToInt32(readRecord[0]);
                    string firstName = Convert.ToString(readRecord[1]);
                    string lastName = Convert.ToString(readRecord[2]);
                    string password = Convert.ToString(readRecord[4]);
                    float savingAccount = Convert.ToSingle(readRecord[5]);
                    float checkingAccount = Convert.ToSingle(readRecord[6]);
                    float investmentAccountBalance = Convert.ToSingle(readRecord[7]);
                    int numberOfAttempts = Convert.ToInt32(readRecord[8]);
                    bool accountStatus = Convert.ToBoolean(readRecord[9]);
                    DateTime dateCreated = Convert.ToDateTime(readRecord[10]);

                    account = new JSONStructure(firstName, lastName, userName, password, savingAccount, checkingAccount,
                        investmentAccountBalance, accountNumber, accountStatus, numberOfAttempts, dateCreated);

                    readRecord.Close(); //make sure to close reader as well
                    connection.Close();
                }
                else
                {
                    throw new ArgumentNullException();
                }

                return account;
            }
            catch (NullReferenceException e)
            {
                //usually means new account
                //Console.WriteLine(e.StackTrace);
                return null;
            }
            catch (Exception e)
            {
                //Console.WriteLine(e.StackTrace);
                return null;
            }


        }

        /*
         * 
         * 
         * @return
         * List of type JSONStructure on success, null on failure
         */
        public AdminJSONStructure? GetFromJSONAdmin(string userName)
        {
            AdminJSONStructure? account;
            SqlDataReader readRecord;
            SqlConnection connection;

            try
            {
                if (fileStringAdmin == null)
                {
                    throw new NullReferenceException();
                }

                connection = new SqlConnection(fileLocationSQL);
                SqlCommand sqlCommand = new SqlCommand("select * from tbl_AdminAccounts where userName = @userName", connection);
                sqlCommand.Parameters.AddWithValue("@userName", System.Data.SqlDbType.VarChar).Value = userName;

                connection.Open();
                readRecord = sqlCommand.ExecuteReader();

                if (readRecord.Read())
                {
                    string firstName = Convert.ToString(readRecord[0]);
                    string lastName = Convert.ToString(readRecord[1]);
                    string passWord = Convert.ToString(readRecord[3]);
                    int accountNumber = Convert.ToInt32(readRecord[4]);
                    int numberOfLoginAttempts = Convert.ToInt32(readRecord[5]);
                    DateTime dateCreated = Convert.ToDateTime(readRecord[6]);

                    account = new AdminJSONStructure(firstName, lastName, userName, passWord, numberOfLoginAttempts, accountNumber, dateCreated);
                }
                else
                {
                    throw new NullReferenceException();
                }

                readRecord.Close();
                connection.Close();
                return account;
            }
            catch (NullReferenceException e)
            {
                //TODO serilog
                //Console.WriteLine(e.StackTrace);
                return null;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.StackTrace);
                return null;
            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="AccountNumber"></param>
        /// <returns></returns>
        public string DeleteRow(int AccountNumber)
        {
            SqlConnection connection = new SqlConnection(fileLocationSQL);
            SqlCommand sqlCommand = new SqlCommand("delete from tableName where accountNumber = @accountNumber", connection);
            sqlCommand.Parameters.AddWithValue("@userName", System.Data.SqlDbType.Int).Value = AccountNumber;


            connection.Open();
            sqlCommand.ExecuteNonQuery();
            connection.Close();

            return "";
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public List<JSONStructure>? returnAllAccountDetails()
        {
            List<JSONStructure> allAccounts = new List<JSONStructure>();
            SqlConnection connection = new SqlConnection(fileLocationSQL);
            SqlCommand sqlCommand = new SqlCommand("select * from tbl_AccountsBaseDetails order by accountNumber", connection);

            try
            {
                connection.Open();
                using (SqlDataReader readData = sqlCommand.ExecuteReader())
                {
  
                    if (readData.HasRows)
                    {
                        while (readData.Read())
                        {
                            int accountNumber = Convert.ToInt32(readData[0]);
                            string firstName = Convert.ToString(readData[1]);
                            string lastName = Convert.ToString(readData[2]);
                            string userName = Convert.ToString(readData[3]);
                            string password = Convert.ToString(readData[4]);
                            float savingAccount = Convert.ToSingle(readData[5]);
                            float checkingAccount = Convert.ToSingle(readData[6]);
                            float investmentAccountBalance = Convert.ToSingle(readData[7]);
                            int numberOfAttempts = Convert.ToInt32(readData[8]);
                            bool accountStatus = Convert.ToBoolean(readData[9]);
                            DateTime dateCreated = Convert.ToDateTime(readData[10]);

                            JSONStructure account = new JSONStructure(firstName, lastName, userName, password, savingAccount, checkingAccount, 
                                investmentAccountBalance, accountNumber, accountStatus, numberOfAttempts, dateCreated);
                            allAccounts.Add(account);
                        }
                    }
                }

                return allAccounts;
            }
            catch(Exception)
            {
                return null;
            }
            finally
            {   
                connection.Close();

            }
        }

        //public string DeleteRowAdmin()
        //{

        //}


        /*
        public bool SaveTransactionToSQL(int accountNumber)
        {

        }
        */
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="accountnumber"></param>
        /// <returns></returns>
        public List<string?>? GetLastTenTransactions(int accountnumber)
        {
            int value = 0;

            SqlConnection connection = new SqlConnection(fileLocationSQL);
            SqlCommand sqlCommand = new SqlCommand("select transaction1, transaction2, transaction3, transaction4, transaction5, " +
                "transaction6, transaction7, transaction8, transaction9, transaction10 from tbl_transactions inner join " +
                "tbl_AccountsBaseDetails on tbl_transactions.accountNumber = tbl_AccountsBaseDetails.accountNumber " +
                "where tbl_transactions.accountNumber = @accountNumber", connection);
            //todo 
            sqlCommand.Parameters.AddWithValue("@accountNumber", System.Data.SqlDbType.Int).Value = accountnumber;
            List<string?> allAccounts = new List<string?>();

            try
            {
                connection.Open();

                SqlDataReader readData = sqlCommand.ExecuteReader();
                

                if(readData.HasRows)
                {
                    if (readData.Read())
                    {
                        //todo i used a while loop befor, but somehow it doesn't work
                        string? item1 = readData[0].ToString();
                        string? item2 = readData[1].ToString();
                        string? item3 = readData[2].ToString();
                        string? item4 = readData[3].ToString();
                        string? item5 = readData[4].ToString();
                        string? item6 = readData[5].ToString();
                        string? item7 = readData[6].ToString();
                        string? item8 = readData[7].ToString();
                        string? item9 = readData[8].ToString();
                        string? item10 = readData[9].ToString();

                        allAccounts.Add(item1);
                        allAccounts.Add(item2);
                        allAccounts.Add(item3);
                        allAccounts.Add(item4);
                        allAccounts.Add(item5);
                        allAccounts.Add(item6);
                        allAccounts.Add(item7);
                        allAccounts.Add(item8);
                        allAccounts.Add(item9);
                        allAccounts.Add(item10);
                    }
                }


                readData.Close(); // maybe have a using?
                return allAccounts;
            }
            catch (Exception)
            {
                return null;
            }
            finally
            {
               
                connection.Close();
            }
        }

        /// <summary>
        /// 
        /// 
        /// 
        /// </summary>
        /// <param name="accountNumber"></param>
        /// <returns></returns>
        /// 
        //TODO add this to program
        public List<DateTime?>? GetLastTenTransactionsDate(int accountNumber)
        {
            int value = 0;

            SqlConnection connection = new SqlConnection(fileLocationSQL);
            SqlCommand sqlCommand = new SqlCommand("select transaction1date, transaction2date, transaction3date, transaction4date, transaction5date, " +
                "transaction6date, transaction7date, transaction8date, transaction9date, transaction10date from tbl_transactions inner join " +
                "tbl_AccountsBaseDetails on tbl_transactions.accountNumber = tbl_AccountsBaseDetails.accountNumber " +
                "where tbl_transactions.accountNumber = @accountNumber", connection);
            //todo 
            sqlCommand.Parameters.AddWithValue("@accountNumber", System.Data.SqlDbType.Int).Value = accountNumber;
            List<DateTime?> allAccounts = new List<DateTime?>();

            try
            {
                connection.Open();

                SqlDataReader readData = sqlCommand.ExecuteReader();

                if (readData.HasRows)
                {
                    if (readData.Read())
                    {
                        //todo i used a while loop befor, but somehow it doesn't work
                        DateTime? item1 = (readData[0] == null) ? null : Convert.ToDateTime(readData[0]);
                        DateTime? item2 = (readData[1] == null) ? null : Convert.ToDateTime(readData[1]);
                        DateTime? item3 = (readData[2] == null) ? null : Convert.ToDateTime(readData[2]);
                        DateTime? item4 = (readData[3] == null) ? null : Convert.ToDateTime(readData[3]);
                        DateTime? item5 = (readData[4] == null) ? null : Convert.ToDateTime(readData[4]);
                        DateTime? item6 = (readData[5] == null) ? null : Convert.ToDateTime(readData[5]);
                        DateTime? item7 = (readData[6] == null) ? null : Convert.ToDateTime(readData[6]);
                        DateTime? item8 = (readData[7] == null) ? null : Convert.ToDateTime(readData[7]);
                        DateTime? item9 = (readData[8] == null) ? null : Convert.ToDateTime(readData[8]);
                        DateTime? item10 = (readData[9] == null) ? null : Convert.ToDateTime(readData[9]);

                        allAccounts.Add(item1);
                        allAccounts.Add(item2);
                        allAccounts.Add(item3);
                        allAccounts.Add(item4);
                        allAccounts.Add(item5);
                        allAccounts.Add(item6);
                        allAccounts.Add(item7);
                        allAccounts.Add(item8);
                        allAccounts.Add(item9);
                        allAccounts.Add(item10);
                    }
                }

                Console.WriteLine("todo remove when done, this is number of transactions " + value);

                readData.Close(); // maybe have a using?
                return allAccounts;
            }
            catch (Exception)
            {
                return null;
            }
            finally
            {
                connection.Close();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="accountName"></param>
        /// <param name="connection"></param>
        /// <returns></returns>
        private bool CreateNewTransactionTable(int accountName, SqlConnection connection)
        {//TODO
            
            SqlCommand sqlCommand = new SqlCommand("insert into tbl_transactions (accountNumber)" +
                "Values(@accountNumber)", connection);
            sqlCommand.Parameters.AddWithValue("@accountNumber", System.Data.SqlDbType.Int).Value = accountName;

            try
            {
                sqlCommand.ExecuteNonQuery();
                return true;

            }
            catch(Exception)
            {
                return false;
            }


        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="accountNumber"></param>
        /// <param name="stringOfTransactions"></param>
        /// <returns></returns>
        public bool? UpdateTransactionTable(int accountNumber, string transactionToRecord, DateTime timeOfTransaction)
        {
            SqlConnection connection;
            connection = new SqlConnection(fileLocationSQL);
            bool hasNull = false;

            List<string?>? listOfTransactions = GetLastTenTransactions(accountNumber);
            List<DateTime?>? listOfTransactionDates = GetLastTenTransactionsDate(accountNumber);

            if(listOfTransactions == null || listOfTransactionDates == null)
            {
                return false;
            }

            for(int countNumber = 0; countNumber < listOfTransactions.Count; countNumber++)
            {
                if(listOfTransactions[countNumber] == null)
                {
                    listOfTransactions.Insert(countNumber, transactionToRecord);
                    listOfTransactionDates.Insert(countNumber, timeOfTransaction);
                    hasNull = true;
                    break;
                }
            }

            if(hasNull == false)
            {
                listOfTransactions.Insert(0, transactionToRecord);
                listOfTransactionDates.Insert(0, timeOfTransaction);
            }

            while(listOfTransactions.Count < 10)
            {
                listOfTransactions.Add(null);
            }

            while(listOfTransactionDates.Count < 10)
            {
                listOfTransactions.Add(null);
            }

            SqlCommand sqlCommand = new SqlCommand("update tbl_transactions set transaction1 = @transaction1, transaction2 = @transaction2," +
                "transaction3 = @transaction3, transaction4 = @transaction4, transaction5 = @transaction5, transaction6 = @transaction6, transaction7 = @transaction7," +
                "transaction8 = @transaction8, transaction9 = @transaction9, transaction10 = @transaction10 where accountNumber = @accountNumber", connection);

            sqlCommand.Parameters.AddWithValue("@accountNumber", System.Data.SqlDbType.Int).Value = accountNumber;
            sqlCommand.Parameters.AddWithValue("@transaction1", System.Data.SqlDbType.VarChar).Value = listOfTransactions[0];
            sqlCommand.Parameters.AddWithValue("@transaction2", System.Data.SqlDbType.VarChar).Value = listOfTransactions[1];
            sqlCommand.Parameters.AddWithValue("@transaction3", System.Data.SqlDbType.VarChar).Value = listOfTransactions[2];
            sqlCommand.Parameters.AddWithValue("@transaction4", System.Data.SqlDbType.VarChar).Value = listOfTransactions[3];
            sqlCommand.Parameters.AddWithValue("@transaction5", System.Data.SqlDbType.VarChar).Value = listOfTransactions[4];
            sqlCommand.Parameters.AddWithValue("@transaction6", System.Data.SqlDbType.VarChar).Value = listOfTransactions[5];
            sqlCommand.Parameters.AddWithValue("@transaction7", System.Data.SqlDbType.VarChar).Value = listOfTransactions[6];
            sqlCommand.Parameters.AddWithValue("@transaction8", System.Data.SqlDbType.VarChar).Value = listOfTransactions[7];
            sqlCommand.Parameters.AddWithValue("@transaction9", System.Data.SqlDbType.VarChar).Value = listOfTransactions[8];
            sqlCommand.Parameters.AddWithValue("@transaction10", System.Data.SqlDbType.VarChar).Value = listOfTransactions[9];

            
            SqlCommand sqlCommandUpdateDates = new SqlCommand("update tbl_transactions set transaction1date = @transaction1date, transaction2date = @transaction2date," +
                "transaction3date = @transaction3date, transaction4date = @transaction4date, transaction5date = @transaction5date, transaction6date = @transaction6date, transaction7date = @transaction7date," +
                "transaction8date = @transaction8date, transaction9date = @transaction9date, transaction10date = @transaction10date " +
                "where accountNumber = @accountNumber", connection);

            sqlCommandUpdateDates.Parameters.AddWithValue("@accountNumber", System.Data.SqlDbType.Int).Value = accountNumber;
            sqlCommandUpdateDates.Parameters.AddWithValue("@transaction1date", System.Data.SqlDbType.DateTime).Value = listOfTransactionDates[0];
            sqlCommandUpdateDates.Parameters.AddWithValue("@transaction2date", System.Data.SqlDbType.DateTime).Value = listOfTransactionDates[1];
            sqlCommandUpdateDates.Parameters.AddWithValue("@transaction3date", System.Data.SqlDbType.DateTime).Value = listOfTransactionDates[2];
            sqlCommandUpdateDates.Parameters.AddWithValue("@transaction4date", System.Data.SqlDbType.DateTime).Value = listOfTransactionDates[3];
            sqlCommandUpdateDates.Parameters.AddWithValue("@transaction5date", System.Data.SqlDbType.DateTime).Value = listOfTransactionDates[4];
            sqlCommandUpdateDates.Parameters.AddWithValue("@transaction6date", System.Data.SqlDbType.DateTime).Value = listOfTransactionDates[5];
            sqlCommandUpdateDates.Parameters.AddWithValue("@transaction7date", System.Data.SqlDbType.DateTime).Value = listOfTransactionDates[6];
            sqlCommandUpdateDates.Parameters.AddWithValue("@transaction8date", System.Data.SqlDbType.DateTime).Value = listOfTransactionDates[7];
            sqlCommandUpdateDates.Parameters.AddWithValue("@transaction9date", System.Data.SqlDbType.DateTime).Value = listOfTransactionDates[8];
            sqlCommandUpdateDates.Parameters.AddWithValue("@transaction10date", System.Data.SqlDbType.DateTime).Value = listOfTransactionDates[9];
            

            try
            {
                connection.Open();
                sqlCommand.ExecuteNonQuery();
                sqlCommandUpdateDates.ExecuteNonQuery();

                return true;

            }
            catch (Exception)
            {
                return null;
            }
            finally
            {
                connection.Close();
            }

        }

    }
}
