﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Serilog;

namespace Project1Bank
{
    public class UserBackend : IUserBackendInterface
    {
        //global fields
        //Dictionary<string, JSONStructure>? allAccounts = new Dictionary<string, JSONStructure>();
        //Dictionary<int, JSONStructure>? allAccountsInteger = new Dictionary<int, JSONStructure>();
        ToAndFromJSON sqlConverter = new ToAndFromJSON();
        //List<JSONStructure> allAccountsList = new List<JSONStructure>();
        protected JSONStructure? currentAccount;

        private static float amountToWithdrawSavings = 20000;
        private static float amountToWithdrawChecking = 50000;
        private static float amountToWithdrawInvestingPercentage = .7f;


        /**
         * constructor ...
         */
        public UserBackend()
        {
            Log.Logger = new LoggerConfiguration().WriteTo.File(@"D://RevStuff//RevProjects//Project1//Project1Bank//SerilogData.txt").CreateLogger();
        }

        public string ReturnUserName()
        {
            try
            {
                if (currentAccount != null && currentAccount.firstName != null)
                {
                    return currentAccount.firstName;
                }
                return "";
            }
            catch(Exception)
            {
                return "";
            }
            
        }

        public int ReturnNumberOfAttempts(string userName)
        {
            try
            {
                JSONStructure? account = sqlConverter.GetFromJSON(userName);

                if (account == null)
                {
                    throw new NullReferenceException();
                }

                return account.numberOfAttempts;
            }
            catch (Exception e)
            {
                Log.Error(e.ToString());
                return -1;
            }
        }

        //README, this must be checked before logging in 
        /// <summary>
        /// 
        /// </summary>
        /// <param name="userName"></param>
        /// <param name="passWord"></param>
        /// <returns> integer value based on success and </returns>
        public int LoginAttempt(string userName, string passWord)
        {
            JSONStructure? tempCurrentAccount;
            try
            {
                //YES I KNOW ITS NOT JSON I DON'T GIVE A SHIT ANYMNORE
                currentAccount = sqlConverter.GetFromJSON(userName);

                if(currentAccount == null || currentAccount.userPassword == null)
                {
                    throw new NullReferenceException("user account could not be found");
                }

                if(currentAccount.numberOfAttempts >= 3)
                {
                    currentAccount.isAccountUnlocked = false;
                    sqlConverter.UpdateSQL(currentAccount);
                }

                if(currentAccount.isAccountUnlocked == false)
                {
                    currentAccount = null;
                    return -1;
                }

                if(!currentAccount.userPassword.Equals(passWord))
                {
                    currentAccount.numberOfAttempts++;
                    sqlConverter.UpdateSQL(currentAccount);
                    return 1;
                }

                currentAccount.numberOfAttempts = 0;
                sqlConverter.UpdateSQL(currentAccount);

                return 0;
            }
            catch(NullReferenceException e)
            {
                currentAccount = null;
                Log.Error(e.ToString());
                return 2;
            }
            catch (Exception e)
            {
                currentAccount = null;
                //TODO use serilog
                Log.Error(e.ToString());
                return 3;
            }
 
        }


        public bool CheckIfAccountExists(string userName)
        {
            if(sqlConverter.CheckIfAccountExists(userName) == false)
            {
                return false;
            }
            return true;
        }

        public bool CheckIfAccountExists(int accountNumber)
        {
            if (sqlConverter.CheckIfAccountExists(accountNumber) == false)
            {
                return false;
            }
            return true;
        }

        /**
         * This method ...
         * 
         * @params
         * 
         * @return
         */
        public bool CheckBalance()
        {
            if(currentAccount == null)
            {
                return false;
            }

            //TODO make a data class that stores these 3 values and returns them, I don't want this class interacting with the UI at all
            Console.WriteLine("Account balance for the Checking Account is: " + currentAccount.checkingAccountBalance);
            Console.WriteLine("Account balance for the Savings Account is: " + currentAccount.savingAccountBalance);
            Console.WriteLine("Account balance for the Investement Account is: " + currentAccount.investmentAccountBalance);

            return true;
        }

        /*
        //depreciated
        public bool LogTransaction(string p_adminOrUser, string p_messageToLog)
        {
            string messageToLogFinalized = p_messageToLog + " transaction made by: " + p_adminOrUser;
            try
            {
  
                if (currentAccount == null)
                {
                    return false;
                }

                if (currentAccount.pastTenTransactions == null)
                {
                    currentAccount.pastTenTransactions = new List<string>();
                    currentAccount.pastTenTransactions.Add(messageToLogFinalized);
                    return true;
                }

                if (currentAccount.pastTenTransactions.Count >= 10)
                {
                    currentAccount.pastTenTransactions.RemoveAt(0);
                    currentAccount.pastTenTransactions.Add(messageToLogFinalized);
                    return true;
                }
                else
                {
                    currentAccount.pastTenTransactions.Add(messageToLogFinalized);
                    return true;
                }

            }
            catch (Exception)
            {
                return false;
            }
        }
        */

        public bool? LogTransaction(string p_adminOrUser, string p_messageToLog, int p_accountNumber, DateTime timeOfTransaction)
        {
            string messageToLogFinalized = p_messageToLog + " transaction made by: " + p_adminOrUser;
            try
            {
                bool? boolValueOfMethod = sqlConverter.UpdateTransactionTable(p_accountNumber, messageToLogFinalized, timeOfTransaction);
                if (boolValueOfMethod == null)
                {
                    throw new Exception();
                }
                else if (boolValueOfMethod.Value == false)
                {
                    return false;
                }
                else
                {
                    return true;
                }

            }
            catch (Exception e)
            {
                Log.Error(e.ToString());
                return null;
            }
        }

        /**
         * This method ...
         * 
         * @params
         * 
         * @return
         */
        public int WithdrawMoney(float amountToWithdraw, accountTypeEnum accountToWithdrawFrom)
        {
            try
            {
                if(currentAccount == null)
                {
                    throw new NullReferenceException();
                }

                string message;
                DateTime currentTime = DateTime.Now;

                switch (accountToWithdrawFrom)
                {
                    case accountTypeEnum.checking:
                        //README: i can turn this into a method for readability, but its such a little amount of code its likely not worth it
                        currentAccount.checkingAccountBalance -= amountToWithdraw;
                        message = "Transaction: withdrew " + amountToWithdraw + " from account " + accountToWithdrawFrom.ToString();
                        if (LogTransaction("User", message, currentAccount.accountNumber, currentTime) == null)
                        {
                            throw new Exception();
                        }
                        if(sqlConverter.UpdateSQL(currentAccount) == false)
                        {
                            throw new Exception();
                        }

                        return 0;

                    case accountTypeEnum.saving:

                        currentAccount.savingAccountBalance -= amountToWithdraw;
                        message = "Transaction: withdrew " + amountToWithdraw + " from account " + accountToWithdrawFrom.ToString();
                        if (LogTransaction("User", message, currentAccount.accountNumber, currentTime) == null)
                        {
                            throw new Exception();
                        }
                        if (sqlConverter.UpdateSQL(currentAccount) == false)
                        {
                            throw new Exception();
                        }

                        return 0;

                    case accountTypeEnum.investment:

                        currentAccount.investmentAccountBalance -= amountToWithdraw;
                        message = "Transaction: withdrew " + amountToWithdraw + " from account " + accountToWithdrawFrom.ToString();
                        if (LogTransaction("User", message, currentAccount.accountNumber, currentTime) == null)
                        {
                            throw new Exception();
                        }
                        if (sqlConverter.UpdateSQL(currentAccount) == false)
                        {
                            throw new Exception();
                        }

                        return 0;

                    default:
                        throw new Exception();
                }

            }
            catch(NullReferenceException e)
            {
                Log.Error(e.ToString());
                return 1;
            }
            catch(Exception e)
            {
                Log.Error(e.ToString());
                return 2;
            }
        }

        /**
         * This method ...
         * 
         * @params
         * 
         * @return
         */
        public int DepositMoney(float amountToDeposit, accountTypeEnum accountToDepositTo)
        {
            string message;

            try
            {
                if (currentAccount == null)
                {
                    throw new NullReferenceException();
                }

                DateTime currentTime = DateTime.Now;

                switch (accountToDepositTo)
                {
                    case accountTypeEnum.checking:
                        currentAccount.checkingAccountBalance += amountToDeposit;
                        message = "Transaction: deposit " + amountToDeposit + " to account " + accountToDepositTo.ToString();
                        if (LogTransaction("User", message, currentAccount.accountNumber, currentTime) == null)
                        {
                            throw new Exception();
                        }
                        sqlConverter.UpdateSQL(currentAccount);
                        return 0;

                    case accountTypeEnum.saving:
                        currentAccount.savingAccountBalance += amountToDeposit;
                        message = "Transaction: deposit " + amountToDeposit + " to account " + accountToDepositTo.ToString();
                        if (LogTransaction("User", message, currentAccount.accountNumber, currentTime) == null)
                        {
                            throw new Exception();
                        }
                        sqlConverter.UpdateSQL(currentAccount);
                        return 0;

                    case accountTypeEnum.investment:
                        currentAccount.investmentAccountBalance += amountToDeposit;
                        message = "Transaction: deposit " + amountToDeposit + " to account " + accountToDepositTo.ToString();
                        if (LogTransaction("User", message, currentAccount.accountNumber, currentTime) == null)
                        {
                            throw new Exception();
                        }
                        sqlConverter.UpdateSQL(currentAccount);
                        return 0;

                    default:
                        throw new Exception();
                }

                
            }
            catch (NullReferenceException e)
            {
                Log.Error(e.ToString());
                return 1;
            }
            catch (Exception e)
            {
                Log.Error(e.ToString());
                return 2;
            }
        }

        public List<string?>? ViewLastTenTransactions()
        {
            try
            {
                List<string?>? returnList = sqlConverter.GetLastTenTransactions(currentAccount.accountNumber);
                
                return returnList;
            }
            catch(Exception)
            {
                return null;
            }
        }
        public List<DateTime?>? ViewLastTenTransactionsDate()
        {
            try
            {
                List<DateTime?>? returnList = sqlConverter.GetLastTenTransactionsDate(currentAccount.accountNumber);

                return returnList;
            }
            catch (Exception e)
            {
                Log.Error(e.ToString());
                return null;
            }
        }

        /**
         * This method ...
         * 
         * @params
         * 
         * @return
         */
        public bool TransferMoney(int otherAccountDetails, float amountToTransfer, accountTypeEnum accountTypeToTransferFrom,
            accountTypeEnum typeOfAccountToTransferTo)
        {
            JSONStructure? accountToTransferTo;

            string message;

            try
            {
                accountToTransferTo = sqlConverter.GetFromJSON(otherAccountDetails);

                if(accountToTransferTo == null)
                {
                    throw new Exception();
                }

                if(currentAccount == null)
                {
                    throw new Exception();
                }

                if(!TransferMoneyHelperAccountToTransferTo(accountToTransferTo, typeOfAccountToTransferTo,
                    accountTypeToTransferFrom, amountToTransfer))
                {
                    throw new Exception();
                }

                sqlConverter.UpdateSQL(accountToTransferTo);
                sqlConverter.UpdateSQL(currentAccount);

                DateTime currentTime = DateTime.Now;

                message = "Transaction: transfer " + amountToTransfer + " from account " + accountTypeToTransferFrom.ToString() + 
                    " to account " + typeOfAccountToTransferTo.ToString();
                if (LogTransaction("User", message, currentAccount.accountNumber, currentTime) == null)
                {
                    throw new Exception();
                }

                return true;
            }
            catch (NullReferenceException e)
            {
                Log.Error(e.ToString());
                return false;
            }
            catch(Exception e)
            {
                Log.Error(e.ToString());
                return false;
            }

        }


        /**
         * This method ...
         * 
         * @params
         * 
         * @return
         */
        public bool CheckIfPasswordsMatch(string passwordToCheck)
        {
            if(passwordToCheck == null)
            {
                return false;
            }

            if(passwordToCheck.Equals(currentAccount?.userPassword))
            {
                return true;
            }

            return false;
        }

        /**
         * This method ...
         * 
         * @params
         * 
         * @return
         */
        public bool ChangePassword(string stringPasswordToChangeTo, int minPasswordLength, int maxPasswordLength)
        {
            if(stringPasswordToChangeTo.Length > minPasswordLength && stringPasswordToChangeTo.Length < maxPasswordLength)
            {
                if(currentAccount == null)
                {
                    return false;
                }

                currentAccount.userPassword = stringPasswordToChangeTo;

                sqlConverter.UpdateSQL(currentAccount);
                return true;
            }

            return false;
        }

        //Helper Methods
        /**
         * this method is responsible for ...
         * 
         * @params 
         * none
         * 
         * @return 
         * void
         */
        /*
        private void RefreshAccounts()
        {
            try
            {
                //note all accounts and all accounts list will not be null, if so return ull
                //allAccounts?.Clear();

                //if(allAccounts == null)
                //{
                    //throw new NullReferenceException();
                }

                allAccountsList.Clear();

                if(allAccountsList == null)
                {
                    throw new NullReferenceException();
                }

                allAccountsList = sqlConverter.GetFromJSON();

                if (allAccountsList == null)
                {
                    //TODO: TESTING ONLY
                    allAccountsList = new List<JSONStructure>();
                    //throw new NullReferenceException("No file found or other issue involving parsing");
                }

                foreach (JSONStructure account in allAccountsList)
                {
                    if (account == null)
                    {
                        throw new NullReferenceException("corrupted file");
                    }

                    if (account?.userName == null)
                    {
                        throw new NullReferenceException("corruped file");
                    }

                    allAccounts?.Add(account.userName, account);

                }
            }
            catch (NullReferenceException e)
            {
                Console.WriteLine(e);
                return;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.StackTrace);
                return;
            }
        }
        
        
        private void RefreshAccountInteger()
        {
            try
            {
                //allAccountsList.Clear();
                //allAccountsInteger.Clear();

                allAccountsList = sqlConverter.GetFromJSON();

                if (allAccountsList == null)
                {
                    throw new NullReferenceException("No file found or other issue involving parsing");
                }

                foreach (JSONStructure account in allAccountsList)
                {
                    if (account == null)
                    {
                        throw new NullReferenceException("corrupted file");
                    }

                    if (account?.userName == null)
                    {
                        throw new NullReferenceException("corruped file");
                    }

                    allAccountsInteger?.Add(account.accountNumber, account);

                }
            }
            catch (NullReferenceException e)
            {
                Console.WriteLine(e);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.StackTrace);
            }
        }
        */

        /*
        private JSONStructure? HelpFindAccountWithAccountId(int accountId)
        {
            JSONStructure? account;
            RefreshAccountInteger();

            try
            {
                if(!allAccountsInteger.ContainsKey(accountId))
                {
                    throw new ArgumentException();
                }

                account = allAccountsInteger[accountId];

                if(account == null)
                {
                    throw new NullReferenceException();
                }
                return account;
            }
            catch(ArgumentException)
            {
                return null;
            }
            catch(NullReferenceException)
            {
                return null;
            }
            catch(Exception)
            {
                return null;
            }

        }
        */

        private bool TransferMoneyHelperAccountToTransferTo(JSONStructure accountToTransferTo, accountTypeEnum accountTypeToTransferTo
            , accountTypeEnum accountTypeToTransferFrom, float amountToTransfer)
        {
            try
            {
                switch(accountTypeToTransferTo)
                {
                    case accountTypeEnum.checking:

                        switch(accountTypeToTransferFrom)
                        {
                            case accountTypeEnum.investment:

                                if(currentAccount == null || accountToTransferTo == null)
                                {
                                    throw new Exception();
                                }

                                accountToTransferTo.checkingAccountBalance += amountToTransfer;
                                currentAccount.investmentAccountBalance -= amountToTransfer;
                                return true;



                            case accountTypeEnum.checking:

                                if (currentAccount == null || accountToTransferTo == null)
                                {
                                    throw new Exception();
                                }

                                accountToTransferTo.checkingAccountBalance += amountToTransfer;
                                currentAccount.checkingAccountBalance -= amountToTransfer;
                                return true; 

                            case accountTypeEnum.saving:

                                if (currentAccount == null || accountToTransferTo == null)
                                {
                                    throw new Exception();
                                }

                                accountToTransferTo.checkingAccountBalance += amountToTransfer;
                                currentAccount.savingAccountBalance -= amountToTransfer;
                                return true;

                            default:
                                return false;
                        }


                    case accountTypeEnum.investment:

                        switch (accountTypeToTransferFrom)
                        {
                            case accountTypeEnum.investment:

                                if (currentAccount == null || accountToTransferTo == null)
                                {
                                    throw new Exception();
                                }

                                accountToTransferTo.investmentAccountBalance += amountToTransfer;
                                currentAccount.investmentAccountBalance -= amountToTransfer;
                                return true;



                            case accountTypeEnum.checking:

                                if (currentAccount == null || accountToTransferTo == null)
                                {
                                    throw new Exception();
                                }

                                accountToTransferTo.investmentAccountBalance += amountToTransfer;
                                currentAccount.checkingAccountBalance -= amountToTransfer;
                                return true;

                            case accountTypeEnum.saving:

                                if (currentAccount == null || accountToTransferTo == null)
                                {
                                    throw new Exception();
                                }

                                accountToTransferTo.investmentAccountBalance += amountToTransfer;
                                currentAccount.savingAccountBalance -= amountToTransfer;
                                return true;

                            default:
                                return false;
                        }

                    case accountTypeEnum.saving:

                        switch (accountTypeToTransferFrom)
                        {
                            case accountTypeEnum.investment:

                                if (currentAccount == null || accountToTransferTo == null)
                                {
                                    throw new Exception();
                                }

                                accountToTransferTo.savingAccountBalance += amountToTransfer;
                                currentAccount.investmentAccountBalance -= amountToTransfer;
                                return true;



                            case accountTypeEnum.checking:

                                if (currentAccount == null || accountToTransferTo == null)
                                {
                                    throw new Exception();
                                }

                                accountToTransferTo.savingAccountBalance += amountToTransfer;
                                currentAccount.checkingAccountBalance -= amountToTransfer;
                                return true;

                            case accountTypeEnum.saving:

                                if (currentAccount == null || accountToTransferTo == null)
                                {
                                    throw new Exception();
                                }

                                accountToTransferTo.savingAccountBalance += amountToTransfer;
                                currentAccount.savingAccountBalance -= amountToTransfer;
                                return true;

                            default:
                                return false;
                        }

                    default:
                        return false;
                }

            }
            catch(Exception e)
            {
                Log.Error(e.ToString());
                return false;
            }
        }

        
        /**
         * this method is responsible for ...
         * 
         * @params 
         * none
         * 
         * @return 
         * void
         */
        /*
        private JSONStructure? HelpFindAccount(string userName)
        {

            try
            {
                if (!allAccounts.ContainsKey(userName))
                {
                    throw new ArgumentException();
                }

                JSONStructure account = allAccounts[userName]; //TODO does it work like this? pass by reference?

                if (account == null)
                {
                    throw new NullReferenceException();
                }

                return account;
            }
            catch (ArgumentException)
            {
                //Console.WriteLine("no such account found");
                return null;
            }
            catch (NullReferenceException e)
            {
                Console.WriteLine(e.StackTrace);
                return null;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.StackTrace);
                return null;
            }

        }
        */

        
        public bool MaxLimitTransactions(accountTypeEnum typeOfAccount, float amountToWithdraw)
        {
            if(currentAccount == null)
            {
                return false;
            }
            switch (typeOfAccount)
            {
                case accountTypeEnum.saving:
                    if (amountToWithdraw > amountToWithdrawSavings)
                    {
                        return false;
                    }
                    return true;
                case accountTypeEnum.checking:
                    if (amountToWithdraw > amountToWithdrawChecking)
                    {
                        return false;
                    }
                    return true;
                case accountTypeEnum.investment:
                    if (amountToWithdraw > amountToWithdrawInvestingPercentage * currentAccount.investmentAccountBalance)
                    {
                        return false;
                    }
                    return true;
                default:
                    return false;
            }
        }
        


    }
}
