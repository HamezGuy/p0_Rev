﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Serilog;

namespace Project1Bank
{
    /*
     * 
     * 
     * 
     * README: there will be no inteface for this class, its not really needed for group development esp as its so high up.
     */
    public class UserGUI
    {
        //global fields
        UserBackend userBackend;
        AdminBackend adminBackend;

        /**
         * This constructor
         * 
         * @params
         * 
         * @return
         */
        public UserGUI()
        {
            adminBackend = new AdminBackend();
            userBackend = new UserBackend();
        }

        /**
         * This method ...
         * 
         * @params
         * 
         * @return
         */
        //TODO impliment user login
        public void UserLoginAndInitialization()
        {

            string ? userInput;
            string userName;
            string passWord;
            int loginInt;
            int loginAttempts;

            PrintTitle();
            while (true)
            {
                try
                {
                    Console.WriteLine("User Login: Please enter your username to log or enter q to exit");

                    userInput = Console.ReadLine();

                    if (userInput == null)
                    {
                        throw new NullReferenceException("Please enter a valid value");
                    }

                    if (userInput == "q" || userInput == "Q")
                    {
                        Console.WriteLine("returning to main menu");
                        return;
                    }

                    if (!userBackend.CheckIfAccountExists(userInput))
                    {
                        throw new ArgumentException("Could not find the username, please enter a valid username");
                    }
                    else
                    {
                        userName = userInput;
                    }

                    break;
                }
                catch (ArgumentException e)
                {
                    Console.WriteLine(e.Message);
                }
                catch (NullReferenceException e)
                {
                    Console.WriteLine(e.Message);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.StackTrace);
                }
            }


            while (true)
            {
                try
                {
                    loginAttempts = userBackend.ReturnNumberOfAttempts(userName);

                    
                    if (loginAttempts >= 3)
                    {
                        Console.WriteLine("more than 3 login attempts on record for this account" +
                            ", account is locked, please enter q to return to main menu");
                    }
                    else
                    {
                        Console.WriteLine("");
                        Console.WriteLine("Welcome " + userName + ", please enter your password to log in or enter q to exit to main menu");
                        Console.WriteLine("Note: login attempts cannot go over 3 attempts, current number of attempts: " + loginAttempts);
                    }

                    userInput = Console.ReadLine();

                    if (userInput == null)
                    {
                        throw new NullReferenceException("Please enter a valid password");
                    }

                    if (userInput == "q" || userInput == "Q")
                    {
                        Console.WriteLine("Exiting to main menu");
                        return;
                    }
                    else if (loginAttempts >= 3)
                    {
                        throw new ArgumentException("");
                    }
                    else
                    {
                        passWord = userInput;
                    }

                    loginInt = userBackend.LoginAttempt(userName, passWord);

                    switch (loginInt)
                    {
                        case -1:
                            throw new ArgumentException("Over 3 password attempts entered, no more login attempts allowed");
                        case 0:
                            Console.WriteLine("Login Successful, entering account");
                            break;
                        case 1:
                            loginAttempts++;
                            throw new ArgumentException("Password does not match, please try again");
                        case 2:
                            throw new NullReferenceException("issue accessing account");
                        case 3:
                            throw new Exception();
                        default:
                            throw new Exception();
                    }

                    break;
                }
                catch (ArgumentException e)
                {
                    Console.WriteLine(e.Message);
                }
                catch (NullReferenceException e)
                {
                    Console.WriteLine(e.Message);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.StackTrace);
                }
            }
            
            while (true)
            {
                ShowOptionsUser();
            }
            
        }

        /// <summary>
        /// 
        /// </summary>
        private void PrintTitle()
        {
            Console.Clear();
            Console.WriteLine(@"
████████ ███████ ███████ ████████ ██████   █████  ███    ██ ██   ██ 
   ██    ██      ██         ██    ██   ██ ██   ██ ████   ██ ██  ██  
   ██    █████   ███████    ██    ██████  ███████ ██ ██  ██ █████   
   ██    ██           ██    ██    ██   ██ ██   ██ ██  ██ ██ ██  ██  
   ██    ███████ ███████    ██    ██████  ██   ██ ██   ████ ██   ██ 
                                                                    
                                                                    
");
        }

 

        /**
         * This method ...
         * 
         * @params
         * 
         * @return
         */
        private void ShowOptionsUser()
        {
            int userIntInput;


            
            Console.WriteLine("Welcome " + userBackend.ReturnUserName() + " to TestBank");

            while (true)
            {
                PrintTitle();

                Console.WriteLine("Please choose from the options below (press 1 for selection 1)");
                Console.WriteLine("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                Console.WriteLine("1. Check Balance");
                Console.WriteLine("2. Withdraw from Account");
                Console.WriteLine("3. Deposit to Account");
                Console.WriteLine("4. Transfer to another Account");
                Console.WriteLine("5. View last 10 transactions");
                Console.WriteLine("6. Change Account password");
                Console.WriteLine("7. Exit the Program"); //should i have it go to the main menu

                try
                {
                    string? tempUserInput = Console.ReadLine();

                    if (tempUserInput == null)
                    {
                        throw new NullReferenceException("Please enter a valid value");
                    }

                    if (int.TryParse(tempUserInput, out userIntInput))
                    {
                        if (userIntInput >= 1 && userIntInput <= 8) 
                            //magic numbers, but is the number of options above, seems self expanitory so didn't make vars
                        {
                            break;
                        }
                        else
                        {
                            throw new ArgumentException("Please enter a currect numerical value between 1-8");
                        }
                    }
                    else
                    {
                        throw new ArgumentException("Please enter a currect numerical value between 1-8");
                    }


                }
                catch (ArgumentException e)
                {
                    Console.WriteLine(e.Message);
                }
                catch (NullReferenceException e)
                {
                    Console.WriteLine(e.Message);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.StackTrace);
                }
            }

            switch (userIntInput)
            {
                case 1:
                    CheckBalance();
                    break;

                case 2:
                    withdrawOrDepositEnum tempWithdraw = withdrawOrDepositEnum.withdraw;
                    WithdrawOrDeposit(tempWithdraw);
                    break;

                case 3:
                    withdrawOrDepositEnum tempDeposit = withdrawOrDepositEnum.deposit;
                    WithdrawOrDeposit(tempDeposit);
                    break;

                case 4:
                    TransferToAnotherAccount();
                    break;

                case 5:
                    ViewLastTenTransactions();
                    break;

                case 6:
                    ChangePassword();
                    break;

                case 7:
                    Console.WriteLine("Thank you for using our program");
                    Environment.Exit(1);
                    break;


                default:
                    Console.WriteLine("error coming here, returning to main menu");
                    return;
            }

            return;
        }

        /**
         * This method ...
         * 
         * @params
         * 
         * @return
         */
        private void CheckBalance()
        {
            try
            {
                PrintTitle();

                Console.WriteLine("Accessing user account balance: ");

                if ( ! userBackend.CheckBalance() )
                {
                    throw new ArgumentException("Issue with the user account, " +
                        "account balance could not be accessed");
                }

            }
            catch(ArgumentException e)
            {
                Console.WriteLine(e.Message);
            }
            catch(Exception e){
                Console.WriteLine(e.StackTrace);
            }

            while (true)
            {
                Console.WriteLine("Please enter q to return to main menu");

                string? userInput = Console.ReadLine().ToLower().Trim();
                if (userInput == null)
                {
                    Console.WriteLine("please enter a valid value");
                }
                else if (userInput == "q")
                {
                    return;
                }
            }

        }

        /**
         * This method ...
         * 
         * @params
         * 
         * @return
         */
        private void WithdrawOrDeposit(withdrawOrDepositEnum withdrawOrDeposit)
        {
            float? amountToWithdrawOrDeposit;
            accountTypeEnum? typeOfAccount;


            while (true)
            {

                PrintTitle();
                try
                {
                    typeOfAccount = TypeOfAccountUserInput("Please enter the type of account " +
                        "you wish to access. Mode:" + withdrawOrDeposit.ToString() );

                    if (!typeOfAccount.HasValue) //double chck this, if not change it to equal to null
                    {
                        return;
                    }
                    

                    break;
                }
                catch (ArgumentException e)
                {
                    Console.WriteLine(e.Message);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.StackTrace);
                }
            }


            while (true)
            {
                try
                {
                    string tempMessage = "Please enter the amount you wish to " + withdrawOrDeposit.ToString() + ", or q to quit" +
                    "(Use decimals to signify seperation between dollars and cents)";
                    

                    amountToWithdrawOrDeposit = PromptUserAmountToUse(tempMessage);
                    if(!amountToWithdrawOrDeposit.HasValue)
                    {
                        return;
                    }

                    if(withdrawOrDeposit == withdrawOrDepositEnum.withdraw)
                    {
                        if (!userBackend.MaxLimitTransactions(typeOfAccount.Value, amountToWithdrawOrDeposit.Value))
                        {
                            throw new ArgumentException("Amount being withdrawn is too high for the " + typeOfAccount.Value.ToString() + " account");
                        }
                    }

                    break;
                }
                catch (ArgumentException e)
                {
                    Console.WriteLine(e.Message);
                }
                catch(NullReferenceException e)
                {
                    Console.WriteLine(e.Message);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.StackTrace);
                }
            }

            if (withdrawOrDeposit.Equals(withdrawOrDepositEnum.deposit))
            {
                userBackend.DepositMoney(amountToWithdrawOrDeposit.Value, typeOfAccount.Value);
            }
            else if(withdrawOrDeposit.Equals(withdrawOrDepositEnum.withdraw))
            {
                userBackend.WithdrawMoney(amountToWithdrawOrDeposit.Value, typeOfAccount.Value);
            }
            else
            {
                Console.WriteLine("error withdrawing or depositing funds");
                
            }


            while (true)
            {
                Console.WriteLine("Please enter q to return to main menu");

                string? userInput = Console.ReadLine().ToLower().Trim();
                if (userInput == null)
                {
                    Console.WriteLine("please enter a valid value");
                }
                else if (userInput == "q")
                {
                    return;
                }
            }
        }

        /**
         * This method ...
         * 
         * @params
         * 
         * @return
         */
        private void TransferToAnotherAccount()
        {
            float? amountToTransfer = null;
            int? accountToTransferTo = null;
            accountTypeEnum? typeOfAccountToTransferFrom = null;
            accountTypeEnum? typeOfAccountToTransferTo = null;

            while(true)
            {
                PrintTitle();
                try
                {
                    accountToTransferTo = PromptUserAccountData();
                    if (!accountToTransferTo.HasValue)
                    {
                        Console.WriteLine("Terminating process and returning to main menu");
                        return;
                    }

                    break;
                }
                catch (ArgumentException e)
                {
                    Console.WriteLine(e.Message);
                }
                catch (NullReferenceException e)
                {
                    Console.WriteLine(e.Message);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.StackTrace);
                }
            }

            while(true)
            {
                try
                {
                    PrintTitle();
                    typeOfAccountToTransferFrom = PromptUserTypeOfAccount("Please enter the type of the account to transfer from");
                    if(!typeOfAccountToTransferFrom.HasValue)
                    {
                        Console.WriteLine("Terminating process, returning to main menu");
                    }

                    bool? clarifyBool = ClarifyUserInput("Are you sure this is the correct type of account, [y]es/[n]o?");
                    switch (clarifyBool)
                    {
                        case true:
                            break; //only other break from while loop
                        case false:
                            throw new ArgumentException("Please enter a new account value");
                        case null:
                            Console.WriteLine("Terminating process exiting to main menu");
                            return;
                    }
                    break;
                }
                catch (ArgumentException e)
                {
                    Console.WriteLine(e.Message);
                }
                catch (NullReferenceException e)
                {
                    Console.WriteLine(e.Message);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.StackTrace);
                }
            }


            while (true)
            {
                try
                {
                    PrintTitle();
                    typeOfAccountToTransferTo = PromptUserTypeOfAccount("Please enter the type of the account to transfer to");
                    if (!typeOfAccountToTransferFrom.HasValue)
                    {
                        Console.WriteLine("Terminating process, returning to main menu");
                    }

                    bool? clarifyBool = ClarifyUserInput("Are you sure this is the correct account type to transfer to [y]es/[n]o?");
                    switch (clarifyBool)
                    {
                        case true:
                            break; //only other break from while loop
                        case false:
                            throw new ArgumentException("Please enter a new account value");
                        case null:
                            Console.WriteLine("Terminating process exiting to main menu");
                            return;
                    }

                    break;
                }
                catch (ArgumentException e)
                {
                    Console.WriteLine(e.Message);
                }
                catch (NullReferenceException e)
                {
                    Console.WriteLine(e.Message);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.StackTrace);
                }
            }
            
            while (true)
            {
                PrintTitle();
                try
                {
                    amountToTransfer = PromptUserAmountToUse("Please input the amount of money you wish to transfer");

                    if (accountToTransferTo == null)
                    {
                        Console.WriteLine("Terminating process and returning to main menu");
                        return;
                    }


                    if (!userBackend.MaxLimitTransactions(typeOfAccountToTransferFrom.Value, amountToTransfer.Value))
                    {
                        throw new ArgumentException("Amount being withdrawn is too high for the " + typeOfAccountToTransferFrom.Value.ToString() + " account");
                    }
                    
                    

                    break;
                }
                catch (ArgumentException e)
                {
                    Console.WriteLine(e.Message);
                }
                catch (NullReferenceException e)
                {
                    Console.WriteLine(e.Message);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.StackTrace);
                }
            }

            if(!amountToTransfer.HasValue || !typeOfAccountToTransferFrom.HasValue || !typeOfAccountToTransferTo.HasValue)
            {
                return;
            }

            
            if(userBackend.TransferMoney(accountToTransferTo.Value, amountToTransfer.Value, typeOfAccountToTransferFrom.Value, typeOfAccountToTransferTo.Value))
            {
                Console.WriteLine("Successful transfer");
            }
            else
            {
                Console.WriteLine("Error transferring funds");
            }

            while (true)
            {
                Console.WriteLine("Please enter q to return to main menu");

                string? userInput = Console.ReadLine().ToLower().Trim();
                if (userInput == null)
                {
                    Console.WriteLine("please enter a valid value");
                }
                else if (userInput == "q")
                {
                    return;
                }
            }
        }

        /**
         * This method ...
         * 
         * @params
         * 
         * @return
         */
        private void ViewLastTenTransactions()
        {
            PrintTitle();

            List<string?>? listOfTransactions = userBackend.ViewLastTenTransactions();
            List<DateTime?>? listOfTransactionDates = userBackend.ViewLastTenTransactionsDate();


            if (listOfTransactions == null || listOfTransactionDates == null)
            {
                Console.WriteLine("Issue accessing transactions, returning to main menu");
                return;
            }

            try
            {
                Console.WriteLine("Showing last 10 trasactions");
                Console.WriteLine("-------------------------------------------");

                if(listOfTransactions.Count < 1)
                {
                    Console.WriteLine("no previous transactions recorded");
                    return;
                }

                for(int i = 0; i < listOfTransactions.Count(); i++)
                {
                    if(listOfTransactions[i] == null || listOfTransactionDates[i] == null)
                    {
                        continue;
                    }
                    else
                    {
                        Console.WriteLine("Previous Transaction: Number " + i + " transaction value: " + listOfTransactions[i] + " transated at the time " + listOfTransactionDates[i]);
                    }
                }

                while(true)
                {
                    Console.WriteLine("Please enter q to return to main menu");

                    string? userInput = Console.ReadLine().ToLower().Trim();
                    if(userInput == null )
                    {
                        Console.WriteLine("please enter a valid value");
                    }
                    else if(userInput == "q")
                    {
                        return;
                    }
                    
                }

                
            }
            catch(Exception)
            {
                Console.WriteLine("Issue accessing transactions, returning to main menu");
                return;
            }
            
            return;
            
        }

        /**
         * This method ...
         * 
         * @params
         * 
         * @return
         */
        private void ChangePassword()
        {
            string? newPassword = null;
            string newPasswordFiltered;

            while(true)
            {
                PrintTitle();

                try
                {
                    Console.WriteLine("Please enter the new password for your account, or enter q to exit to main menu");
                    Console.WriteLine("Password must be greater than 8 values and less than 30 values");
                    newPassword = Console.ReadLine();
                    if(newPassword == null)
                    {
                        throw new NullReferenceException("Please enter a valid value");
                    }

                    if(newPassword == "q" || newPassword == "Q")
                    {
                        Console.WriteLine("Terminating process, exiting to main menu");
                        return;
                    }

                    //TODO change these magic numbers to be get from userbackend
                    if(newPassword.Length < 8 || newPassword.Length > 30)
                    {
                        throw new ArgumentException("Password is either too long or too short, please enter a new password");
                    }

                    newPasswordFiltered = newPassword;
                    break;
                }
                catch (ArgumentException e)
                {
                    Console.WriteLine(e.Message);
                }
                catch (NullReferenceException e)
                {
                    Console.WriteLine(e.Message);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.StackTrace);
                }

            }
            
            if(userBackend.ChangePassword(newPasswordFiltered, 8, 30)) //TODO change magic numbers to valid values
            {
                Console.WriteLine("Successful Password change");
            }
            else
            {
                Console.WriteLine("Error changing password");
            }

            while (true)
            {
                Console.WriteLine("Please enter q to return to main menu");

                string? userInput = Console.ReadLine().ToLower().Trim();
                if (userInput == null)
                {
                    Console.WriteLine("please enter a valid value");
                }
                else if (userInput == "q")
                {
                    return;
                }
            }
        }


        //HELPER METHODS, helps above
        /**
         * This method ...
         * 
         * @params
         * 
         * @return
         */
        private bool? ClarifyUserInput(string messageToPrint)
        {
            while (true)
            {
                try
                {
                    string tempUserInput;

                    Console.WriteLine(messageToPrint);
                    //README: Example Are you sure this is the correct value you want to remove?, press q to exit
                    Console.WriteLine("Press q to terminate process and exit to main menu");

                    tempUserInput = Console.ReadLine().Trim().ToLower();

                    if (tempUserInput == null)
                    {
                        throw new NullReferenceException("Please enter a valid value (yes, no, y, n, or q)");
                    }

                    if (tempUserInput.Equals("yes") || tempUserInput.Equals("y"))
                    {
                        return true;
                    }
                    else if (tempUserInput.Equals("no") || tempUserInput.Equals("n"))
                    {
                        return false;
                    }
                    else if (tempUserInput.Equals("q"))
                    {
                        return null;
                    }
                    else
                    {
                        throw new ArgumentException("Please enter a valid value (yes, no, y, n, or q)");
                    }
                    

                }
                catch (ArgumentException e)
                {
                    Console.WriteLine(e.Message);
                }
                catch (NullReferenceException e)
                {
                    Console.WriteLine(e.Message);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.StackTrace);
                }
            }
        }


        /**
         * This method ...
         * 
         * @params
         * 
         * @return
         */
        //could make this boolean and pass by reference type?
        //could also make accounts have a certain range????? 
        private int? PromptUserAccountData()
        {
            int accountData = -1;

            while (true)
            {
                try
                {
                    Console.WriteLine("Please type in the account number you wish to access or press q to exit: ");

                    string tempUserInput = Console.ReadLine();
                    if (tempUserInput == null)
                    {
                        throw new NullReferenceException("please enter a valid value");
                    }

                    if(tempUserInput.Equals("q"))
                    {
                        Console.WriteLine("Exiting back to main menu");
                        return null;
                    }

                    if (!int.TryParse(tempUserInput, out accountData))
                    {
                        throw new ArgumentException("please enter a valid account value");
                    }

                    if (!adminBackend.CheckIfAccountExists(accountData))
                    {
                        throw new ArgumentException("Account not found, please enter a valid account value");
                    }

                    Console.WriteLine("Is this the correct account you want to access? " + accountData + " [y]es or [n]o");

                    tempUserInput = Console.ReadLine().Trim().ToLower();

                    if (tempUserInput == null)
                    {
                        throw new NullReferenceException("null value detected, please enter a valid value (yes, y, no, or n):");
                    }

                    if ((tempUserInput.Equals("y") || tempUserInput.Equals("yes")))
                    {
                        return accountData;
                    }
                    else if ((tempUserInput.Equals("no") || tempUserInput.Equals("n")))
                    {
                        throw new ArgumentException("Invalid account number selected, enter a new account number");
                    }
                    else
                    {
                        throw new ArgumentException("Please enter a valid value (yes, y, no, or n):");
                    }

                }
                catch (ArgumentException e)
                {
                    Console.WriteLine(e.Message);
                }
                catch (NullReferenceException e)
                {
                    Console.WriteLine(e.Message);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.StackTrace);
                }
            }

        }

        /**
         * This method ...
         * 
         * @params
         * 
         * @return
         */
        protected accountTypeEnum? PromptUserTypeOfAccount(string messageToPrint)
        {
            //TODO need to check for this one
            accountTypeEnum? returnUserAccountType = null;
            string? userInput;
            int userEnteredValue;

            while(true)
            {
                
                try
                {
                    //message is type of account you want to access
                    Console.WriteLine(messageToPrint);
                    Console.WriteLine("1. checking account\n2. savings account\n3. investment account");
                    Console.WriteLine("Please enter either a numerical value (1, 2, 3) correlation to the" +
                        " account type or enter q to return to main menu");

                    userInput = Console.ReadLine().Trim().ToLower();

                    if (userInput == null)
                    {
                        throw new NullReferenceException("Please enter a valid value (1, 2, or 3)");
                    }

                    if(userInput == "q")
                    {
                        return null;
                    }

                    if (!int.TryParse(userInput, out userEnteredValue))
                    {
                        throw new ArgumentException("Please enter a valid (1, 2, or 3)");
                    }

                    switch (userEnteredValue)
                    {
                        case 1:
                            returnUserAccountType = accountTypeEnum.checking;
                            return returnUserAccountType;
                        case 2:
                            returnUserAccountType = accountTypeEnum.saving;
                            return returnUserAccountType;
                        case 3:
                            returnUserAccountType = accountTypeEnum.investment;
                            return returnUserAccountType;
                        default:
                            return null;
                    }
                }
                catch (ArgumentException e)
                {
                    Console.WriteLine(e.Message);
                }
                catch (NullReferenceException e)
                {
                    Console.WriteLine(e.Message);
                }
                catch (Exception)
                {
                    return null;
                }
            }
        }

        /**
         * This method ...
         * 
         * @params
         * 
         * @return
         */
        protected float? PromptUserAmountToUse(string messageToPrint)
        {
            float amountToUse = -1;
            while (true)
            {
                try
                {
                    Console.WriteLine(messageToPrint);
                    Console.WriteLine("enter q to quit to main menu");

                    string tempUserInput = Console.ReadLine().Trim().ToLower();
                    if (tempUserInput == null)
                    {
                        throw new NullReferenceException("please enter a valid value");
                    }

                    if (tempUserInput.Equals("q"))
                    {
                        Console.WriteLine("Exiting back to main menu");
                        return null;
                    }

                    if (!float.TryParse(tempUserInput, out amountToUse))
                    {
                        throw new ArgumentException("please enter a valid value");
                    }

                    Console.WriteLine("Is this the correct amount? " + amountToUse + " [y]es or [n]o");

                    tempUserInput = Console.ReadLine().Trim().ToLower();

                    if (tempUserInput == null)
                    {
                        throw new NullReferenceException("null value detected, please enter a valid value (yes, y, no, or n):");
                    }

                    if (!(tempUserInput.Equals("y") || tempUserInput.Equals("yes")))
                    {
                        throw new ArgumentException("Incorrect account value (press yes or y to confirm correct account)");
                    }

                    break;
                }
                catch (ArgumentException e)
                {
                    Console.WriteLine(e.Message);
                }
                catch (NullReferenceException e)
                {
                    Console.WriteLine(e.Message);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.StackTrace);
                }
            }

            return amountToUse;
        }

        /**
         * This method ...
         * 
         * @params
         * 
         * @return
         */
        private accountTypeEnum? TypeOfAccountUserInput(string messageToPrint)
        {
            accountTypeEnum? returnUserAccountType;
            string? userInput;
            int userEnteredValue;

            while (true)
            {
                try
                {
                    //message is type of account you want to access
                    Console.WriteLine(messageToPrint);
                    Console.WriteLine("1. checking account\n2. savings account\n3. investment account");
                    Console.WriteLine("Please enter either a numerical value (1, 2, 3) correlation to the account type");
                    Console.WriteLine("enter q to quit to main menu");

                    userInput = Console.ReadLine().Trim().ToLower();

                    if (userInput == null)
                    {
                        throw new NullReferenceException("Input cannot be blank, please enter a valid value (1, 2, or 3)");
                    }

                    if(userInput == "q")
                    {
                        Console.WriteLine("Terminating process, returning to main menu");
                        return null;
                    }

                    if (!int.TryParse(userInput, out userEnteredValue))
                    {
                        throw new ArgumentException("Please enter a valid value (1, 2, or 3)");
                    }

                    switch (userEnteredValue)
                    {
                        case 1:
                            returnUserAccountType = accountTypeEnum.checking;
                            return returnUserAccountType;
                        case 2:
                            returnUserAccountType = accountTypeEnum.saving;
                            return returnUserAccountType;
                        case 3:
                            returnUserAccountType = accountTypeEnum.investment;
                            return returnUserAccountType;
                        default:
                            return null;
                    }
                }
                catch (ArgumentException e)
                {
                    Console.WriteLine(e.Message);
                }
                catch (NullReferenceException e)
                {
                    Console.WriteLine(e.Message);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.StackTrace);
                }
            }
        }

    }
}
