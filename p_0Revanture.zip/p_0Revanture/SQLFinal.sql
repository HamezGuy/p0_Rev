use bankingDB

create table tbl_AccountsBaseDetails(
	accountNumber int not null,
	firstName varchar(50) not null,
	lastName varchar(50) not null,
	userName varchar(50) not null,
	userPassword varchar(50) not null,
	savingAccount float not null,
	checkingAccount float not null,
	investmentAccount float not null,
	numberOfAttempts int not null,
	accountStatus bit not null,
	dateCreated datetime not null,
	unique(userName),
	primary key (accountNumber)
)

create table tbl_AdminAccounts(
	firstName varchar(50) not null,
	lastName varchar(50) not null,
	userName varchar(50) not null,
	passWord varchar(50) not null,
	accountNumber int not null,
	numberOfLogins int not null,
	dateTime datetime not null,
	primary key (accountNumber),
	unique(userName)
)

create table tbl_transactions(
	accountNumber int not null,
	transaction1 varchar(100) not null,
	transaction2 varchar(100) not null,
	transaction3 varchar(100) not null,
	transaction4 varchar(100) not null,
	transaction5 varchar(100) not null,
	transaction6 varchar(100) not null,
	transaction7 varchar(100) not null,
	transaction8 varchar(100) not null,
	transaction9 varchar(100) not null,
	transaction10 varchar(100) not null,
	transaction1date datetime not null,
	transaction2date datetime not null,
	transaction3date datetime not null,
	transaction4date datetime not null,
	transaction5date datetime not null,
	transaction6date datetime not null,
	transaction7date datetime not null,
	transaction8date datetime not null,
	transaction9date datetime not null,
	transaction10date datetime not null,

	CONSTRAINT FK_accountNumber FOREIGN KEY (accountNumber)
	references tbl_AccountsBaseDetails (accountNumber)
)


INSERT INTO tbl_AccountsBaseDetails ([accountNumber], [firstName], [lastName], [userName], [userPassword], [savingAccountBalance],
 [checkingAccountBalance], [investmentAccountBalance], [numberOfAttempts], 
 [accountStatus], [dateCreated]) VALUES(1, 'testName', 'testName', 'testName', 'testName', 0, 0
 , 0, 0, 0, 2004-05-23)

insert into tbl_AdminAccounts ([firstName], 
[lastName], [userName], [passWord], [accountNumber], 
[numberOfLoginAttempts], [dateTime]) values('testAdmin', 
 'testAdmin', 'testAdmin', 'testAdmin', 0, 0, 2004-05-23)

update tbl_AccountsBaseDetails set firstName = 'testName1', numberOfAttempts = 0, lastName = 'testName1',
 userPassword = 'testName1', savingAccountBalance = 0, checkingAccountBalance = 0, 
 investmentAccountBalance = 0, accountStatus = 1, userName = 'testName1' where accountNumber = 1

update tbl_AdminAccounts set firstName = 'testAdmin1', lastName = 'testAdmin1',
userName = 'testAdmin1', passWord = 'testAdmin1', numberOfLoginAttempts = 0,
dateTime = 2004-05-23 where accountNumber = 0

Select count(*) from tbl_AccountsBaseDetails where accountNumber = 1

Select count(*) from tbl_AccountsBaseDetails where userName = 'testName1'

Select count(*) from tbl_AdminAccounts where accountNumber = 1

select count(*) from tbl_AdminAccounts where userName = 'testAdmin1'

select max(accountNumber) from tbl_AccountsBaseDetails

select transaction1, transaction2, transaction3, transaction4, transaction5, 
transaction6, transaction7, transaction8, transaction9, transaction10 from tbl_transactions inner join 
tbl_AccountsBaseDetails on tbl_transactions.accountNumber = tbl_AccountsBaseDetails.accountNumber 
where tbl_transactions.accountNumber = 1

select transaction1date, transaction2date, transaction3date, transaction4date, transaction5date, 
transaction6date, transaction7date, transaction8date, transaction9date, transaction10date from tbl_transactions inner join 
tbl_AccountsBaseDetails on tbl_transactions.accountNumber = tbl_AccountsBaseDetails.accountNumber 
where tbl_transactions.accountNumber = 1

insert into tbl_transactions (accountNumber)
Values(3)

update tbl_transactions set transaction1 = 'testTransaction', transaction2 = 'testTransaction',
transaction3 = 'testTransaction', transaction4 = 'testTransaction', transaction5 = 'testTransaction', 
transaction6 = 'testTransaction', transaction7 = 'testTransaction',
transaction8 = 'testTransaction', transaction9 = 'testTransaction', transaction10 = 'testTransaction'
where accountNumber = 1